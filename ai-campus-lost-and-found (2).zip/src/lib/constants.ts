export const CATEGORIES = [
  "Electronics",
  "Student ID cards",
  "Wallets",
  "Keys",
  "Bags and backpacks",
  "Books and notebooks",
  "Clothing",
  "Accessories",
  "Documents",
  "Water bottles",
  "Other",
] as const;

export const CAMPUS_SPOTS = [
  "Central Library",
  "Main Canteen / Cafeteria",
  "Lecture Hall A",
  "Lecture Hall B",
  "Computer Lab",
  "Science & Physics Lab",
  "Sports Complex & Gym",
  "Auditorium",
  "Hostel Block A",
  "Hostel Block B",
  "Parking Area",
  "Bus Stop",
  "Admin & Registration Block",
  "Campus Grounds & Quad",
] as const;

export const COLORS = [
  "Black",
  "White",
  "Grey",
  "Blue",
  "Navy",
  "Red",
  "Green",
  "Yellow",
  "Orange",
  "Purple",
  "Pink",
  "Brown",
  "Silver",
  "Gold",
  "Multicolour",
] as const;

export const PREFERRED_CONTACTS = [
  { value: "chat", label: "In-app ReFind chat (recommended)" },
  { value: "phone", label: "Phone number (shared upon verification)" },
  { value: "email", label: "College email (shared upon verification)" },
  { value: "desk", label: "Campus Lost & Found desk" },
] as const;

export type Category = (typeof CATEGORIES)[number];
export type CampusSpot = (typeof CAMPUS_SPOTS)[number];
