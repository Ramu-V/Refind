import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function initials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
];

export function formatDate(d: Date | string | null | undefined) {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  if (isNaN(date.getTime())) return "—";
  return `${MONTHS[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;
}

export function timeAgo(d: Date | string | null | undefined) {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  if (isNaN(date.getTime())) return "—";
  const secs = Math.floor((Date.now() - date.getTime()) / 1000);
  if (secs < 60) return "just now";
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return formatDate(date);
}

export function toDateInput(d: Date | string | null | undefined) {
  if (!d) return "";
  const date = typeof d === "string" ? new Date(d) : d;
  if (isNaN(date.getTime())) return "";
  return date.toISOString().split("T")[0];
}

const STOP = new Set([
  "the","a","an","and","or","but","in","on","at","to","for","of","with","by",
  "from","is","are","was","were","be","my","i","it","its","this","that","near",
  "lost","found","please","have","has","had","if","you","your","me","we","our",
  "somewhere","around","about","there","here","very","just","also","while","item",
  "belonging","please","help","thanks","thank",
]);

export function keywordsOf(text: string): string[] {
  const words = text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !STOP.has(w))
    .map((w) => (w.length > 3 && w.endsWith("s") ? w.slice(0, -1) : w));
  return [...new Set(words)];
}

export interface MatchAnalysis {
  score: number;
  signals: {
    categoryMatch: boolean;
    colorMatch: boolean;
    brandMatch: boolean;
    locationMatch: boolean;
    dateProximityDays: number;
    keywordOverlap: string[];
  };
  explanation: string;
}

/** Rule-based multi-factor similarity score (0-100) between a lost and a found report. */
export function calculateMatch(
  lost: {
    category: string;
    color?: string | null;
    brand?: string | null;
    location: string;
    occurredOn: Date | string;
    keywords: string[];
    title?: string;
  },
  found: {
    category: string;
    color?: string | null;
    brand?: string | null;
    location: string;
    occurredOn: Date | string;
    keywords: string[];
    title?: string;
  }
): MatchAnalysis {
  let score = 0;
  const reasons: string[] = [];

  // 1. Category (30 pts)
  const categoryMatch =
    lost.category.toLowerCase().trim() === found.category.toLowerCase().trim();
  if (categoryMatch) {
    score += 30;
    reasons.push(`Same category: ${lost.category}`);
  }

  // 2. Color (15 pts)
  const colorMatch =
    Boolean(lost.color) &&
    Boolean(found.color) &&
    lost.color!.toLowerCase().trim() === found.color!.toLowerCase().trim();
  if (colorMatch) {
    score += 15;
    reasons.push(`Matching colour: ${lost.color}`);
  }

  // 3. Brand (15 pts)
  const brandMatch =
    Boolean(lost.brand) &&
    Boolean(found.brand) &&
    lost.brand!.toLowerCase().trim() === found.brand!.toLowerCase().trim();
  if (brandMatch) {
    score += 15;
    reasons.push(`Matching brand: ${lost.brand}`);
  }

  // 4. Location (15 pts)
  const locationMatch =
    lost.location.toLowerCase().trim() === found.location.toLowerCase().trim();
  if (locationMatch) {
    score += 15;
    reasons.push(`Same location: ${lost.location}`);
  }

  // 5. Date proximity (10 pts)
  const dLost = typeof lost.occurredOn === "string" ? new Date(lost.occurredOn) : lost.occurredOn;
  const dFound = typeof found.occurredOn === "string" ? new Date(found.occurredOn) : found.occurredOn;
  const days = Math.round(Math.abs(dLost.getTime() - dFound.getTime()) / 86400000);

  if (days === 0) {
    score += 10;
    reasons.push("Reported on the same day");
  } else if (days <= 2) {
    score += 8;
    reasons.push(`Reported ${days} day${days > 1 ? "s" : ""} apart`);
  } else if (days <= 5) {
    score += 5;
    reasons.push(`Reported within ${days} days`);
  } else if (days <= 10) {
    score += 2;
  }

  // 6. Keywords overlap (15 pts)
  const sLost = new Set(lost.keywords);
  const sFound = new Set(found.keywords);
  const overlap = [...sLost].filter((w) => sFound.has(w));
  const unionSize = new Set([...sLost, ...sFound]).size || 1;

  if (overlap.length > 0) {
    const jaccard = overlap.length / unionSize;
    const kwScore = Math.min(15, Math.round(jaccard * 30));
    score += kwScore;
    reasons.push(`Shared keywords: ${overlap.slice(0, 3).join(", ")}`);
  }

  const finalScore = Math.min(100, Math.max(0, score));
  const explanation =
    reasons.length > 0
      ? `AI Match (${finalScore}%): ${reasons.join(" • ")}.`
      : "Low confidence match based on general similarity.";

  return {
    score: finalScore,
    signals: {
      categoryMatch,
      colorMatch,
      brandMatch,
      locationMatch,
      dateProximityDays: days,
      keywordOverlap: overlap,
    },
    explanation,
  };
}

export function matchScore(
  a: {
    category: string;
    color?: string | null;
    brand?: string | null;
    location: string;
    occurredOn: Date | string;
    keywords: string[];
  },
  b: {
    category: string;
    color?: string | null;
    brand?: string | null;
    location: string;
    occurredOn: Date | string;
    keywords: string[];
  }
) {
  return calculateMatch(a, b).score;
}
