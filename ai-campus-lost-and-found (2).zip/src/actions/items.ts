"use server";

import { revalidatePath } from "next/cache";
import { and, asc, desc, eq, gte, ilike, lte, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { items, matches, notifications, storedItemImages, users } from "@/db/schema";
import { requireUser } from "@/lib/session";
import { calculateMatch, keywordsOf } from "@/lib/utils";

export type ItemState = { error?: string; id?: string };

function parseItemForm(formData: FormData) {
  return {
    kind: String(formData.get("kind") ?? "lost") as "lost" | "found",
    title: String(formData.get("title") ?? "").trim(),
    description: String(formData.get("description") ?? "").trim(),
    category: String(formData.get("category") ?? "").trim(),
    color: String(formData.get("color") ?? "").trim(),
    brand: String(formData.get("brand") ?? "").trim(),
    location: String(formData.get("location") ?? "").trim(),
    campusArea: String(formData.get("campusArea") ?? "").trim(),
    occurredOn: String(formData.get("occurredOn") ?? "").trim(),
    imageUrl: String(formData.get("imageUrl") ?? "").trim(),
    preferredContact: String(formData.get("preferredContact") ?? "chat").trim(),
  };
}

function validate(d: ReturnType<typeof parseItemForm>) {
  if (d.title.length < 3) return "Title must be at least 3 characters long.";
  if (d.description.length < 10) return "Please describe the item in at least 10 characters.";
  if (!d.category) return "Please choose a valid category.";
  if (!d.location) return "Please choose where the event occurred.";
  if (!d.occurredOn) return "Please select the date.";
  const occ = new Date(d.occurredOn);
  if (isNaN(occ.getTime())) return "Please provide a valid date.";
  if (occ > new Date(Date.now() + 86400000)) return "The date cannot be in the future.";
  return null;
}

const IMAGE_URL_PREFIX = "/api/images/";
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function storedImageIdFromUrl(imageUrl: string): string | null {
  if (!imageUrl.startsWith(IMAGE_URL_PREFIX)) return null;
  const id = imageUrl.slice(IMAGE_URL_PREFIX.length);
  return UUID_PATTERN.test(id) ? id : null;
}

async function validateImageReference(
  imageUrl: string,
  ownerId: string,
  itemId?: string,
  existingImageUrl?: string | null
): Promise<string | null> {
  if (!imageUrl) return null;

  const imageId = storedImageIdFromUrl(imageUrl);
  if (imageId) {
    const [image] = await db
      .select({ ownerId: storedItemImages.ownerId, itemId: storedItemImages.itemId })
      .from(storedItemImages)
      .where(eq(storedItemImages.id, imageId))
      .limit(1);

    if (!image) return "That uploaded image is no longer available. Please upload it again.";
    if (image.ownerId !== ownerId) return "You can only attach images you uploaded.";
    if (image.itemId && image.itemId !== itemId) return "That image is already attached to another report.";
    return null;
  }

  // Preserve existing seeded/external image URLs on edits; new uploads must use ReFind storage.
  if (itemId && existingImageUrl === imageUrl) return null;
  return "Please upload the image using the ReFind photo uploader before saving.";
}

/** Recalculate matches for an item against active opposite-kind items */
export async function syncMatchesForItem(itemId: string) {
  const [item] = await db.select().from(items).where(eq(items.id, itemId)).limit(1);
  if (!item || item.status === "returned" || item.status === "closed") return;

  const oppositeKind = item.kind === "lost" ? "found" : "lost";
  const candidates = await db
    .select()
    .from(items)
    .where(
      and(
        eq(items.kind, oppositeKind),
        ne(items.status, "returned"),
        ne(items.status, "closed"),
        ne(items.ownerId, item.ownerId)
      )
    );

  // Clean old matches involving this item
  await db
    .delete(matches)
    .where(
      or(eq(matches.lostItemId, item.id), eq(matches.foundItemId, item.id))
    );

  for (const candidate of candidates) {
    const lostItem = item.kind === "lost" ? item : candidate;
    const foundItem = item.kind === "found" ? item : candidate;

    const analysis = calculateMatch(lostItem, foundItem);
    if (analysis.score < 40) continue;

    await db.insert(matches).values({
      lostItemId: lostItem.id,
      foundItemId: foundItem.id,
      score: analysis.score,
      explanation: analysis.explanation,
      signals: analysis.signals,
      status: "suggested",
    });

    // Notify the other owner if score is high
    if (analysis.score >= 50) {
      await db.insert(notifications).values({
        userId: candidate.ownerId,
        kind: "possible_match",
        title: "Potential match detected",
        body: `"${item.title}" looks like a ${analysis.score}% match for your ${candidate.kind} item "${candidate.title}".`,
        href: `/app/items/${item.id}`,
      });
    }
  }
}

export async function createItem(formData: FormData): Promise<ItemState> {
  const user = await requireUser();
  const d = parseItemForm(formData);
  const problem = validate(d);
  if (problem) return { error: problem };

  const imageProblem = await validateImageReference(d.imageUrl, user.id);
  if (imageProblem) return { error: imageProblem };
  const imageId = storedImageIdFromUrl(d.imageUrl);

  const created = await db.transaction(async (tx) => {
    const [row] = await tx
      .insert(items)
      .values({
        ownerId: user.id,
        kind: d.kind,
        title: d.title,
        description: d.description,
        category: d.category,
        color: d.color || null,
        brand: d.brand || null,
        location: d.location,
        campusArea: d.campusArea || null,
        occurredOn: new Date(d.occurredOn),
        imageUrl: d.imageUrl || null,
        preferredContact: d.preferredContact || "chat",
        keywords: keywordsOf(`${d.title} ${d.description} ${d.brand} ${d.category} ${d.location}`),
      })
      .returning();

    if (imageId) {
      const linked = await tx
        .update(storedItemImages)
        .set({ itemId: row.id })
        .where(and(eq(storedItemImages.id, imageId), eq(storedItemImages.ownerId, user.id)))
        .returning({ id: storedItemImages.id });
      if (linked.length !== 1) throw new Error("Uploaded image ownership changed before the report was saved.");
    }

    return row;
  });

  await syncMatchesForItem(created.id);

  revalidatePath("/app/browse");
  revalidatePath("/app/my-items");
  revalidatePath("/app/matches");
  revalidatePath("/app");
  revalidatePath("/");
  return { id: created.id };
}

export async function updateItem(
  id: string,
  formData: FormData
): Promise<ItemState> {
  const user = await requireUser();
  const d = parseItemForm(formData);
  const problem = validate(d);
  if (problem) return { error: problem };

  const [existing] = await db.select().from(items).where(eq(items.id, id)).limit(1);
  if (!existing) return { error: "Listing not found." };
  if (existing.ownerId !== user.id) return { error: "You can only edit your own listings." };

  const imageProblem = await validateImageReference(d.imageUrl, user.id, id, existing.imageUrl);
  if (imageProblem) return { error: imageProblem };
  const oldImageId = storedImageIdFromUrl(existing.imageUrl ?? "");
  const newImageId = storedImageIdFromUrl(d.imageUrl);

  await db.transaction(async (tx) => {
    if (oldImageId && oldImageId !== newImageId) {
      await tx
        .delete(storedItemImages)
        .where(
          and(
            eq(storedItemImages.id, oldImageId),
            eq(storedItemImages.ownerId, user.id),
            eq(storedItemImages.itemId, id)
          )
        );
    }

    await tx
      .update(items)
      .set({
        kind: d.kind,
        title: d.title,
        description: d.description,
        category: d.category,
        color: d.color || null,
        brand: d.brand || null,
        location: d.location,
        campusArea: d.campusArea || null,
        occurredOn: new Date(d.occurredOn),
        imageUrl: d.imageUrl || null,
        preferredContact: d.preferredContact || "chat",
        keywords: keywordsOf(`${d.title} ${d.description} ${d.brand} ${d.category} ${d.location}`),
        updatedAt: new Date(),
      })
      .where(eq(items.id, id));

    if (newImageId && newImageId !== oldImageId) {
      const linked = await tx
        .update(storedItemImages)
        .set({ itemId: id })
        .where(and(eq(storedItemImages.id, newImageId), eq(storedItemImages.ownerId, user.id)))
        .returning({ id: storedItemImages.id });
      if (linked.length !== 1) throw new Error("Uploaded image ownership changed before the report was updated.");
    }
  });

  await syncMatchesForItem(id);

  revalidatePath("/app/browse");
  revalidatePath("/app/my-items");
  revalidatePath("/app/matches");
  revalidatePath(`/app/items/${id}`);
  revalidatePath("/app");
  revalidatePath("/");
  return { id };
}

export async function deleteItem(id: string): Promise<ItemState> {
  const user = await requireUser();
  const [existing] = await db.select().from(items).where(eq(items.id, id)).limit(1);
  if (!existing) return { error: "Listing not found." };
  if (existing.ownerId !== user.id) return { error: "You can only delete your own listings." };

  await db.delete(items).where(eq(items.id, id));

  revalidatePath("/app/browse");
  revalidatePath("/app/my-items");
  revalidatePath("/app/matches");
  revalidatePath("/app");
  revalidatePath("/");
  return {};
}

export async function markReturned(id: string): Promise<ItemState> {
  const user = await requireUser();
  const [existing] = await db.select().from(items).where(eq(items.id, id)).limit(1);
  if (!existing) return { error: "Listing not found." };
  if (existing.ownerId !== user.id) return { error: "Not authorized." };

  await db.update(items).set({ status: "returned", updatedAt: new Date() }).where(eq(items.id, id));

  revalidatePath("/app/browse");
  revalidatePath("/app/my-items");
  revalidatePath("/app/matches");
  revalidatePath(`/app/items/${id}`);
  revalidatePath("/app");
  revalidatePath("/");
  return {};
}

export async function reopenItem(id: string): Promise<ItemState> {
  const user = await requireUser();
  const [existing] = await db.select().from(items).where(eq(items.id, id)).limit(1);
  if (!existing) return { error: "Listing not found." };
  if (existing.ownerId !== user.id) return { error: "Not authorized." };

  await db.update(items).set({ status: "open", updatedAt: new Date() }).where(eq(items.id, id));
  await syncMatchesForItem(id);

  revalidatePath("/app/my-items");
  revalidatePath("/app/matches");
  revalidatePath(`/app/items/${id}`);
  revalidatePath("/app");
  return {};
}

export async function closeItem(id: string): Promise<ItemState> {
  const user = await requireUser();
  const [existing] = await db.select().from(items).where(eq(items.id, id)).limit(1);
  if (!existing) return { error: "Listing not found." };
  if (existing.ownerId !== user.id) return { error: "Not authorized." };

  await db.update(items).set({ status: "closed", updatedAt: new Date() }).where(eq(items.id, id));

  revalidatePath("/app/my-items");
  revalidatePath(`/app/items/${id}`);
  return {};
}

/* ───────── Queries ───────── */

export type ItemWithOwner = {
  item: typeof items.$inferSelect;
  owner: typeof users.$inferSelect;
};

export async function searchItems(opts: {
  q?: string;
  kind?: string;
  category?: string;
  location?: string;
  color?: string;
  status?: string;
  fromDate?: string;
  toDate?: string;
  sort?: string;
}) {
  const where = [];

  if (opts.q) {
    const like = `%${opts.q}%`;
    where.push(
      or(
        ilike(items.title, like),
        ilike(items.description, like),
        ilike(items.brand, like),
        ilike(items.category, like),
        ilike(items.location, like),
        ilike(items.color, like)
      )
    );
  }
  if (opts.kind === "lost" || opts.kind === "found") {
    where.push(eq(items.kind, opts.kind));
  }
  if (opts.category) where.push(eq(items.category, opts.category));
  if (opts.location) where.push(eq(items.location, opts.location));
  if (opts.color) where.push(eq(items.color, opts.color));
  if (
    opts.status === "open" ||
    opts.status === "claimed" ||
    opts.status === "returned" ||
    opts.status === "closed"
  ) {
    where.push(eq(items.status, opts.status));
  }
  if (opts.fromDate) {
    const from = new Date(opts.fromDate);
    if (!isNaN(from.getTime())) where.push(gte(items.occurredOn, from));
  }
  if (opts.toDate) {
    const to = new Date(opts.toDate);
    if (!isNaN(to.getTime())) where.push(lte(items.occurredOn, to));
  }

  let order = desc(items.createdAt);
  if (opts.sort === "oldest") order = asc(items.createdAt);
  if (opts.sort === "date_desc") order = desc(items.occurredOn);
  if (opts.sort === "date_asc") order = asc(items.occurredOn);

  const rows = await db
    .select({ item: items, owner: users })
    .from(items)
    .innerJoin(users, eq(items.ownerId, users.id))
    .where(where.length ? and(...where) : undefined)
    .orderBy(order);

  return rows;
}

export async function getItem(id: string) {
  const [row] = await db
    .select({ item: items, owner: users })
    .from(items)
    .innerJoin(users, eq(items.ownerId, users.id))
    .where(eq(items.id, id))
    .limit(1);
  return row ?? null;
}

export interface MatchDetails {
  match: typeof matches.$inferSelect;
  lostItem: typeof items.$inferSelect;
  lostOwner: typeof users.$inferSelect;
  foundItem: typeof items.$inferSelect;
  foundOwner: typeof users.$inferSelect;
}

/** Get potential matches for a user (either items they lost matched with found, or items they found matched with lost) */
export async function getUserMatches(userId: string): Promise<MatchDetails[]> {
  const allMatches = await db
    .select()
    .from(matches)
    .orderBy(desc(matches.score));

  const allItems = await db.select().from(items);
  const allUsers = await db.select().from(users);

  const itemMap = new Map(allItems.map((i) => [i.id, i]));
  const userMap = new Map(allUsers.map((u) => [u.id, u]));

  const relevant = allMatches
    .map((m) => {
      const lostItem = itemMap.get(m.lostItemId);
      const foundItem = itemMap.get(m.foundItemId);
      if (!lostItem || !foundItem) return null;

      const lostOwner = userMap.get(lostItem.ownerId);
      const foundOwner = userMap.get(foundItem.ownerId);
      if (!lostOwner || !foundOwner) return null;

      // Filter matches relevant to this user
      if (lostItem.ownerId !== userId && foundItem.ownerId !== userId) return null;

      return {
        match: m,
        lostItem,
        lostOwner,
        foundItem,
        foundOwner,
      };
    })
    .filter(Boolean) as MatchDetails[];

  return relevant;
}

/** Suggested counterpart listings for a given item */
export async function suggestionsFor(id: string) {
  const [base] = await db.select().from(items).where(eq(items.id, id)).limit(1);
  if (!base) return [];

  const opposite = base.kind === "lost" ? "found" : "lost";
  const rows = await db
    .select({ item: items, owner: users })
    .from(items)
    .innerJoin(users, eq(items.ownerId, users.id))
    .where(
      and(
        eq(items.kind, opposite),
        ne(items.status, "returned"),
        ne(items.status, "closed"),
        ne(items.ownerId, base.ownerId)
      )
    );

  return rows
    .map((r) => {
      const lost = base.kind === "lost" ? base : r.item;
      const found = base.kind === "found" ? base : r.item;
      const analysis = calculateMatch(lost, found);
      return {
        ...r,
        score: analysis.score,
        explanation: analysis.explanation,
        signals: analysis.signals,
      };
    })
    .filter((r) => r.score >= 40)
    .sort((a, b) => b.score - a.score)
    .slice(0, 4);
}
