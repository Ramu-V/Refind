"use server";

import { revalidatePath } from "next/cache";
import { desc, eq, and } from "drizzle-orm";
import { db } from "@/db";
import { notifications, users } from "@/db/schema";
import { requireUser } from "@/lib/session";

export type AccountState = { error?: string; ok?: boolean };

export async function updateProfile(formData: FormData): Promise<AccountState> {
  const user = await requireUser();
  const name = String(formData.get("name") ?? "").trim();
  const role = String(formData.get("role") ?? "student") as
    | "student"
    | "teacher"
    | "staff";
  const department = String(formData.get("department") ?? "").trim();
  const phone = String(formData.get("phone") ?? "").trim();

  if (name.length < 2) return { error: "Please enter your full name." };

  await db
    .update(users)
    .set({
      name,
      role,
      department: department || null,
      phone: phone || null,
    })
    .where(eq(users.id, user.id));

  revalidatePath("/app/settings");
  revalidatePath("/app");
  return { ok: true };
}

export async function listNotifications(userId: string) {
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function markNotificationSeen(id: string): Promise<AccountState> {
  const user = await requireUser();
  await db
    .update(notifications)
    .set({ seen: true })
    .where(and(eq(notifications.id, id), eq(notifications.userId, user.id)));
  revalidatePath("/app/notifications");
  revalidatePath("/app");
  return { ok: true };
}

export async function markAllNotificationsSeen(): Promise<AccountState> {
  const user = await requireUser();
  await db
    .update(notifications)
    .set({ seen: true })
    .where(eq(notifications.userId, user.id));
  revalidatePath("/app/notifications");
  revalidatePath("/app");
  return { ok: true };
}
