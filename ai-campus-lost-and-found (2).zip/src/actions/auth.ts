"use server";

import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { AuthError } from "next-auth";
import { signIn, signOut } from "@/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { requireUser } from "@/lib/session";

export type FormState = { error?: string; ok?: boolean; message?: string };

const ACCENTS = [
  "#1e3a8a",
  "#244b99",
  "#3161b8",
  "#0f9d6e",
  "#b45309",
  "#7c3aed",
  "#be185d",
  "#0f766e",
];

export async function signUp(
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "").toLowerCase().trim();
  const password = String(formData.get("password") ?? "");
  const confirmPassword = String(formData.get("confirmPassword") ?? "");
  const role = String(formData.get("role") ?? "student") as
    | "student"
    | "teacher"
    | "staff";
  const department = String(formData.get("department") ?? "").trim();
  const agreeToTerms = formData.get("agreeToTerms") === "on" || formData.get("agreeToTerms") === "true";

  if (name.length < 2) return { error: "Please enter your full name (minimum 2 characters)." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { error: "Please enter a valid college or personal email address." };
  }
  if (password.length < 6) {
    return { error: "Password must be at least 6 characters long." };
  }
  if (password !== confirmPassword) {
    return { error: "Password and Confirm Password do not match." };
  }
  if (!agreeToTerms) {
    return { error: "You must agree to the ReFind community guidelines and terms." };
  }

  const [existing] = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);

  if (existing) {
    return { error: "An account with this email already exists. Please log in instead." };
  }

  const hashed = await bcrypt.hash(password, 10);
  await db.insert(users).values({
    name,
    email,
    password: hashed,
    role,
    department: department || null,
    accent: ACCENTS[Math.floor(Math.random() * ACCENTS.length)],
  });

  try {
    await signIn("credentials", { email, password, redirect: false });
  } catch {
    return { error: "Account created, but automatic sign-in failed. Please log in directly." };
  }
  return { ok: true };
}

export async function logIn(
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const email = String(formData.get("email") ?? "").toLowerCase().trim();
  const password = String(formData.get("password") ?? "");

  if (!email || !password) {
    return { error: "Email address and password are required." };
  }

  try {
    await signIn("credentials", { email, password, redirect: false });
  } catch (err) {
    if (err instanceof AuthError) {
      return { error: "Incorrect email or password. Please try again." };
    }
    return { error: "Incorrect email or password. Please try again." };
  }
  return { ok: true };
}

export async function logOut() {
  await signOut({ redirectTo: "/" });
}

export async function changePassword(
  formData: FormData
): Promise<FormState> {
  const user = await requireUser();
  const currentPassword = String(formData.get("currentPassword") ?? "");
  const newPassword = String(formData.get("newPassword") ?? "");
  const confirmNewPassword = String(formData.get("confirmNewPassword") ?? "");

  if (!currentPassword || !newPassword) {
    return { error: "All password fields are required." };
  }
  if (newPassword.length < 6) {
    return { error: "New password must be at least 6 characters." };
  }
  if (newPassword !== confirmNewPassword) {
    return { error: "New password and confirmation do not match." };
  }

  const [dbUser] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  if (!dbUser) return { error: "User account not found." };

  const valid = await bcrypt.compare(currentPassword, dbUser.password);
  if (!valid) {
    return { error: "Your current password is incorrect." };
  }

  const newHash = await bcrypt.hash(newPassword, 10);
  await db.update(users).set({ password: newHash }).where(eq(users.id, user.id));

  return { ok: true, message: "Password updated successfully." };
}
