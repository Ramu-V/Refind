"use server";

import { revalidatePath } from "next/cache";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { claims, items, messages, notifications, users } from "@/db/schema";
import { requireUser } from "@/lib/session";

export type ClaimState = { error?: string; ok?: boolean };

export async function submitClaim(
  itemId: string,
  formData: FormData
): Promise<ClaimState> {
  const user = await requireUser();
  const message = String(formData.get("message") ?? "").trim();
  const proof = String(formData.get("proof") ?? "").trim();

  if (message.length < 10) {
    return { error: "Please write at least 10 characters so the owner can verify you." };
  }

  const [item] = await db.select().from(items).where(eq(items.id, itemId)).limit(1);
  if (!item) return { error: "This listing no longer exists." };
  if (item.ownerId === user.id) return { error: "This is your own listing." };
  if (item.status === "returned") return { error: "This item has already been returned." };

  const [dupe] = await db
    .select()
    .from(claims)
    .where(
      and(
        eq(claims.itemId, itemId),
        eq(claims.claimantId, user.id),
        eq(claims.status, "pending")
      )
    )
    .limit(1);
  if (dupe) return { error: "You already have a pending request on this listing." };

  await db.insert(claims).values({
    itemId,
    claimantId: user.id,
    message,
    proof: proof || null,
  });

  await db.insert(notifications).values({
    userId: item.ownerId,
    kind: "claim_received",
    title: item.kind === "found" ? "Someone claims this item" : "Someone may have found it",
    body: `${user.name} responded to your listing "${item.title}".`,
    href: `/app/requests`,
  });

  revalidatePath(`/app/items/${itemId}`);
  revalidatePath("/app/requests");
  return { ok: true };
}

export async function decideClaim(
  claimId: string,
  approve: boolean
): Promise<ClaimState> {
  const user = await requireUser();

  const [row] = await db
    .select({ claim: claims, item: items, claimant: users })
    .from(claims)
    .innerJoin(items, eq(claims.itemId, items.id))
    .innerJoin(users, eq(claims.claimantId, users.id))
    .where(eq(claims.id, claimId))
    .limit(1);

  if (!row) return { error: "Request not found." };
  if (row.item.ownerId !== user.id) return { error: "Not allowed." };

  await db
    .update(claims)
    .set({ status: approve ? "approved" : "declined" })
    .where(eq(claims.id, claimId));

  if (approve) {
    await db.update(items).set({ status: "claimed" }).where(eq(items.id, row.item.id));
    await db.insert(notifications).values({
      userId: row.claim.claimantId,
      kind: "claim_approved",
      title: "Your request was approved",
      body: `${user.name} approved your request for "${row.item.title}". You can now chat to arrange the handover.`,
      href: `/app/messages/${claimId}`,
    });
  } else {
    await db.insert(notifications).values({
      userId: row.claim.claimantId,
      kind: "claim_declined",
      title: "Your request was declined",
      body: `Your request for "${row.item.title}" was declined.`,
      href: `/app/items/${row.item.id}`,
    });
  }

  revalidatePath("/app/requests");
  revalidatePath("/app/messages");
  revalidatePath(`/app/items/${row.item.id}`);
  return { ok: true };
}

/* ───────── Queries ───────── */

/** Claims other people made on my listings. */
export async function incomingClaims(userId: string) {
  return db
    .select({ claim: claims, item: items, claimant: users })
    .from(claims)
    .innerJoin(items, eq(claims.itemId, items.id))
    .innerJoin(users, eq(claims.claimantId, users.id))
    .where(eq(items.ownerId, userId))
    .orderBy(desc(claims.createdAt));
}

/** Claims I made on other people's listings. */
export async function outgoingClaims(userId: string) {
  return db
    .select({ claim: claims, item: items, owner: users })
    .from(claims)
    .innerJoin(items, eq(claims.itemId, items.id))
    .innerJoin(users, eq(items.ownerId, users.id))
    .where(eq(claims.claimantId, userId))
    .orderBy(desc(claims.createdAt));
}

export async function claimsOnItem(itemId: string) {
  return db
    .select({ claim: claims, claimant: users })
    .from(claims)
    .innerJoin(users, eq(claims.claimantId, users.id))
    .where(eq(claims.itemId, itemId))
    .orderBy(desc(claims.createdAt));
}
