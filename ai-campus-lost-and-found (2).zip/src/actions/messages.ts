"use server";

import { revalidatePath } from "next/cache";
import { and, asc, desc, eq, ne, or } from "drizzle-orm";
import { db } from "@/db";
import { claims, items, messages, notifications, users } from "@/db/schema";
import { requireUser } from "@/lib/session";

export type MessageState = { error?: string; ok?: boolean };

/** A chat thread exists for every approved claim. */
export async function threadsFor(userId: string) {
  const rows = await db
    .select({ claim: claims, item: items, owner: users })
    .from(claims)
    .innerJoin(items, eq(claims.itemId, items.id))
    .innerJoin(users, eq(items.ownerId, users.id))
    .where(eq(claims.status, "approved"))
    .orderBy(desc(claims.createdAt));

  const mine = rows.filter(
    (r) => r.item.ownerId === userId || r.claim.claimantId === userId
  );
  if (!mine.length) return [];

  const claimants = await db.select().from(users);
  const userMap = new Map(claimants.map((u) => [u.id, u]));

  const allMessages = await db.select().from(messages).orderBy(desc(messages.createdAt));

  return mine.map((r) => {
    const partnerId =
      r.item.ownerId === userId ? r.claim.claimantId : r.item.ownerId;
    const threadMessages = allMessages.filter((m) => m.claimId === r.claim.id);
    return {
      claim: r.claim,
      item: r.item,
      partner: userMap.get(partnerId)!,
      lastMessage: threadMessages[0] ?? null,
      unread: threadMessages.filter((m) => m.senderId !== userId && !m.seen).length,
    };
  });
}

export async function getThread(claimId: string, userId: string) {
  const [row] = await db
    .select({ claim: claims, item: items, owner: users })
    .from(claims)
    .innerJoin(items, eq(claims.itemId, items.id))
    .innerJoin(users, eq(items.ownerId, users.id))
    .where(eq(claims.id, claimId))
    .limit(1);

  if (!row) return null;
  if (row.claim.status !== "approved") return null;
  if (row.item.ownerId !== userId && row.claim.claimantId !== userId) return null;

  const partnerId =
    row.item.ownerId === userId ? row.claim.claimantId : row.item.ownerId;
  const [partner] = await db.select().from(users).where(eq(users.id, partnerId)).limit(1);

  const thread = await db
    .select({ message: messages, sender: users })
    .from(messages)
    .innerJoin(users, eq(messages.senderId, users.id))
    .where(eq(messages.claimId, claimId))
    .orderBy(asc(messages.createdAt));

  // mark partner's messages as seen
  await db
    .update(messages)
    .set({ seen: true })
    .where(and(eq(messages.claimId, claimId), ne(messages.senderId, userId)));

  return { claim: row.claim, item: row.item, partner, messages: thread };
}

export async function sendMessage(
  claimId: string,
  formData: FormData
): Promise<MessageState> {
  const user = await requireUser();
  const body = String(formData.get("body") ?? "").trim();
  if (!body) return { error: "Message cannot be empty." };
  if (body.length > 1000) return { error: "Message is too long." };

  const [row] = await db
    .select({ claim: claims, item: items })
    .from(claims)
    .innerJoin(items, eq(claims.itemId, items.id))
    .where(eq(claims.id, claimId))
    .limit(1);

  if (!row) return { error: "Conversation not found." };
  if (row.claim.status !== "approved") return { error: "This conversation is not active." };
  if (row.item.ownerId !== user.id && row.claim.claimantId !== user.id) {
    return { error: "Not allowed." };
  }

  await db.insert(messages).values({
    claimId,
    senderId: user.id,
    body,
  });

  const partnerId =
    row.item.ownerId === user.id ? row.claim.claimantId : row.item.ownerId;

  await db.insert(notifications).values({
    userId: partnerId,
    kind: "new_message",
    title: "New message",
    body: `${user.name}: ${body.slice(0, 70)}${body.length > 70 ? "…" : ""}`,
    href: `/app/messages/${claimId}`,
  });

  revalidatePath(`/app/messages/${claimId}`);
  revalidatePath("/app/messages");
  return { ok: true };
}
