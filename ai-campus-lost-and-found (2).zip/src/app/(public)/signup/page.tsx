"use client";

import { useActionState, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { AlertCircle, ArrowLeft, Check, Loader2, ShieldCheck } from "lucide-react";
import { signUp, type FormState } from "@/actions/auth";
import { Button, Card, Input, Label, Select } from "@/components/ui";
import { Wordmark } from "@/components/logo";

export default function SignupPage() {
  const router = useRouter();
  const [state, action, pending] = useActionState<FormState, FormData>(signUp, {});
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [clientError, setClientError] = useState("");

  useEffect(() => {
    if (state.ok) {
      router.push("/app");
      router.refresh();
    }
  }, [state.ok, router]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    setClientError("");
    if (password !== confirmPassword) {
      e.preventDefault();
      setClientError("Password and Confirm Password must match.");
      return;
    }
  };

  const displayedError = clientError || state.error;

  return (
    <main className="mesh flex min-h-screen flex-col items-center justify-center px-5 py-12">
      <Link
        href="/"
        className="mb-8 inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-navy-700"
      >
        <ArrowLeft className="h-4 w-4" /> Back to home
      </Link>

      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Wordmark size={42} className="justify-center" />
          <h1 className="mt-6 text-2xl font-extrabold tracking-tight text-ink">
            Create your account
          </h1>
          <p className="mt-1.5 text-sm text-muted">
            Lost it. List it. ReFind it.
          </p>
        </div>

        <Card className="p-6">
          <form action={action} onSubmit={handleSubmit} className="space-y-4">
            {displayedError && (
              <div className="flex items-start gap-2 rounded-xl bg-red-50 px-3.5 py-2.5 text-[13px] font-medium text-red-700">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{displayedError}</span>
              </div>
            )}

            <div>
              <Label htmlFor="name">Full name *</Label>
              <Input
                id="name"
                name="name"
                placeholder="e.g. Alex Sharma"
                required
                disabled={pending}
              />
            </div>

            <div>
              <Label htmlFor="email">College or personal email *</Label>
              <Input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                placeholder="you@college.edu"
                required
                disabled={pending}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="role">I am a *</Label>
                <Select id="role" name="role" defaultValue="student" disabled={pending}>
                  <option value="student">Student</option>
                  <option value="teacher">Teacher / Faculty</option>
                  <option value="staff">College Staff</option>
                </Select>
              </div>
              <div>
                <Label htmlFor="department">Department</Label>
                <Input
                  id="department"
                  name="department"
                  placeholder="e.g. Computer Science"
                  disabled={pending}
                />
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="new-password"
                  placeholder="Min 6 characters"
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={pending}
                />
              </div>
              <div>
                <Label htmlFor="confirmPassword">Confirm Password *</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  autoComplete="new-password"
                  placeholder="Repeat password"
                  minLength={6}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  disabled={pending}
                />
              </div>
            </div>

            <div className="pt-1">
              <label className="flex items-start gap-2.5 text-xs text-muted cursor-pointer">
                <input
                  type="checkbox"
                  name="agreeToTerms"
                  required
                  defaultChecked
                  disabled={pending}
                  className="mt-0.5 h-4 w-4 rounded border-line text-navy-700 focus:ring-navy-500"
                />
                <span>
                  I agree to the ReFind campus guidelines, verification rules, and privacy policy.
                </span>
              </label>
            </div>

            <Button type="submit" className="w-full" disabled={pending}>
              {pending && <Loader2 className="h-4 w-4 animate-spin" />}
              {pending ? "Creating account…" : "Register account"}
            </Button>
          </form>

          <p className="mt-5 text-center text-sm text-muted">
            Already have an account?{" "}
            <Link href="/login" className="font-bold text-navy-700 hover:underline">
              Log in
            </Link>
          </p>
        </Card>

        <div className="mt-6 flex items-center justify-center gap-2 text-xs text-muted">
          <ShieldCheck className="h-4 w-4 text-emerald-600" />
          <span>Your contact info is never shared publicly</span>
        </div>
      </div>
    </main>
  );
}
