"use client";

import { useActionState, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { AlertCircle, ArrowLeft, Check, Loader2, Sparkles, UserCheck } from "lucide-react";
import { logIn, type FormState } from "@/actions/auth";
import { Button, Card, Input, Label } from "@/components/ui";
import { Wordmark } from "@/components/logo";

const DEMO_PERSONAS = [
  {
    name: "Aarav Sharma",
    role: "Student (CS)",
    email: "aarav@college.edu",
    desc: "Lost water bottle, active campus searcher",
  },
  {
    name: "Meera Iyer",
    role: "Student (Biotech)",
    email: "meera@college.edu",
    desc: "Found earbuds with active approved chat thread",
  },
  {
    name: "Imran Qureshi",
    role: "Staff (Library)",
    email: "imran@college.edu",
    desc: "Has incoming verification requests to review",
  },
  {
    name: "Dr. Kavita Rao",
    role: "Teacher (Physics)",
    email: "kavita@college.edu",
    desc: "Found water bottle & spectacles in lecture hall",
  },
];

export default function LoginPage() {
  const router = useRouter();
  const [state, action, pending] = useActionState<FormState, FormData>(logIn, {});
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    if (state.ok) {
      router.push("/app");
      router.refresh();
    }
  }, [state.ok, router]);

  const selectPersona = (pEmail: string) => {
    setEmail(pEmail);
    setPassword("refind123");
  };

  return (
    <main className="mesh flex min-h-screen flex-col items-center justify-center px-5 py-12">
      <Link
        href="/"
        className="mb-8 inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-navy-700"
      >
        <ArrowLeft className="h-4 w-4" /> Back to home
      </Link>

      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Wordmark size={42} className="justify-center" />
          <h1 className="mt-6 text-2xl font-extrabold tracking-tight text-ink">
            Welcome back
          </h1>
          <p className="mt-1.5 text-sm text-muted">
            Log in to manage your listings, view matches, and reply to requests.
          </p>
        </div>

        <Card className="p-6">
          <form action={action} className="space-y-4">
            {state.error && (
              <div className="flex items-start gap-2 rounded-xl bg-red-50 px-3.5 py-2.5 text-[13px] font-medium text-red-700">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{state.error}</span>
              </div>
            )}

            <div>
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                placeholder="you@college.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={pending}
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label htmlFor="password" className="mb-0">Password</Label>
              </div>
              <Input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={pending}
              />
            </div>

            <Button type="submit" className="w-full" disabled={pending}>
              {pending && <Loader2 className="h-4 w-4 animate-spin" />}
              {pending ? "Signing in…" : "Sign In to ReFind"}
            </Button>
          </form>

          <p className="mt-5 text-center text-sm text-muted">
            New to ReFind?{" "}
            <Link href="/signup" className="font-bold text-navy-700 hover:underline">
              Create an account
            </Link>
          </p>
        </Card>

        {/* Demo persona quick switcher */}
        <div className="mt-6 rounded-2xl border border-navy-100 bg-white/90 p-4 shadow-sm backdrop-blur">
          <div className="flex items-center justify-between mb-2.5">
            <span className="flex items-center gap-1.5 text-xs font-bold text-navy-800">
              <Sparkles className="h-3.5 w-3.5 text-navy-600" /> Demo Accounts
            </span>
            <span className="text-[11px] text-muted">Password: <code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-navy-700">refind123</code></span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {DEMO_PERSONAS.map((p) => (
              <button
                key={p.email}
                type="button"
                onClick={() => selectPersona(p.email)}
                className="flex flex-col items-start p-2.5 rounded-xl border border-line bg-navy-50/50 hover:bg-navy-50 hover:border-navy-300 text-left transition-all"
              >
                <span className="text-xs font-bold text-ink truncate w-full">{p.name}</span>
                <span className="text-[10px] text-navy-600 font-medium">{p.role}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
