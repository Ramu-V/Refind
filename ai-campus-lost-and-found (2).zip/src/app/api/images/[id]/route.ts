import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { storedItemImages } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  if (!UUID_PATTERN.test(id)) {
    return NextResponse.json({ error: "Image not found." }, { status: 404 });
  }

  try {
    const [image] = await db
      .select({
        data: storedItemImages.data,
        contentType: storedItemImages.contentType,
        size: storedItemImages.size,
      })
      .from(storedItemImages)
      .where(eq(storedItemImages.id, id))
      .limit(1);

    if (!image) {
      return NextResponse.json({ error: "Image not found." }, { status: 404 });
    }

    return new Response(new Uint8Array(image.data), {
      status: 200,
      headers: {
        "Content-Type": image.contentType,
        "Content-Length": String(image.size),
        "Content-Disposition": "inline",
        "X-Content-Type-Options": "nosniff",
        // The ID is unique per upload; bytes and MIME type never change.
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch (error) {
    console.error("Persistent image read failed:", error);
    return NextResponse.json({ error: "Image could not be loaded." }, { status: 500 });
  }
}
