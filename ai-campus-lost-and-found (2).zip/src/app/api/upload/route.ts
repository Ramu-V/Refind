import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/db";
import { storedItemImages } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

type ImageKind = { contentType: "image/jpeg" | "image/png" | "image/webp"; extension: string };

function detectImageKind(bytes: Buffer): ImageKind | null {
  // PNG signature
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4e &&
    bytes[3] === 0x47 &&
    bytes[4] === 0x0d &&
    bytes[5] === 0x0a &&
    bytes[6] === 0x1a &&
    bytes[7] === 0x0a
  ) {
    return { contentType: "image/png", extension: "png" };
  }

  // JPEG / JPG / JFIF signature
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return { contentType: "image/jpeg", extension: "jpg" };
  }

  // WebP uses a RIFF container with WEBP marker at bytes 8-11.
  if (
    bytes.length >= 12 &&
    bytes.toString("ascii", 0, 4) === "RIFF" &&
    bytes.toString("ascii", 8, 12) === "WEBP"
  ) {
    return { contentType: "image/webp", extension: "webp" };
  }

  return null;
}

function safeFileName(name: string, extension: string) {
  const cleaned = name
    .normalize("NFKC")
    .replace(/[\\/\0-\x1f\x7f]/g, "")
    .trim()
    .slice(0, 100);
  return cleaned || `refind-image.${extension}`;
}

export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    const ownerId = session?.user?.id;
    if (!ownerId) {
      return NextResponse.json({ error: "Sign in before uploading an image." }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json({ error: "Choose an image file to upload." }, { status: 400 });
    }
    if (file.size <= 0) {
      return NextResponse.json({ error: "The selected image is empty." }, { status: 400 });
    }
    if (file.size > MAX_IMAGE_BYTES) {
      return NextResponse.json({ error: "Image must be 5 MB or smaller." }, { status: 413 });
    }

    const bytes = Buffer.from(await file.arrayBuffer());
    const imageKind = detectImageKind(bytes);
    if (!imageKind) {
      return NextResponse.json(
        { error: "Unsupported or invalid image. Upload a valid JPG, PNG, or WebP file." },
        { status: 415 }
      );
    }

    // Do not trust a declared browser MIME type if it contradicts the file signature.
    const declaredType = file.type.toLowerCase();
    const declaredIsAllowed =
      declaredType === "" ||
      declaredType === imageKind.contentType ||
      (imageKind.contentType === "image/jpeg" &&
        (declaredType === "image/jpg" || declaredType === "image/pjpeg"));
    if (!declaredIsAllowed) {
      return NextResponse.json(
        { error: "The image file type does not match its contents." },
        { status: 415 }
      );
    }

    const [stored] = await db
      .insert(storedItemImages)
      .values({
        ownerId,
        data: bytes,
        contentType: imageKind.contentType,
        originalName: safeFileName(file.name, imageKind.extension),
        size: bytes.byteLength,
      })
      .returning({ id: storedItemImages.id });

    return NextResponse.json(
      {
        id: stored.id,
        url: `/api/images/${stored.id}`,
      },
      { status: 201, headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("Persistent image upload failed:", error);
    return NextResponse.json(
      { error: "The image could not be stored. Please try again." },
      { status: 500 }
    );
  }
}
