import Link from "next/link";
import { desc, eq, count } from "drizzle-orm";
import {
  ArrowRight,
  ClipboardList,
  Handshake,
  MapPin,
  MessageCircle,
  PackageSearch,
  Search,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import { db } from "@/db";
import { items, users } from "@/db/schema";
import { Badge, Button, Card } from "@/components/ui";
import { Logo, Wordmark } from "@/components/logo";
import { ItemTile } from "@/components/item-tile";
import { currentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

async function getLandingData() {
  const [totalItems, totalLost, totalFound, returnedCount, peopleCount, recentReports] =
    await Promise.all([
      db.select({ n: count() }).from(items),
      db.select({ n: count() }).from(items).where(eq(items.kind, "lost")),
      db.select({ n: count() }).from(items).where(eq(items.kind, "found")),
      db.select({ n: count() }).from(items).where(eq(items.status, "returned")),
      db.select({ n: count() }).from(users),
      db
        .select({ item: items, owner: users })
        .from(items)
        .innerJoin(users, eq(items.ownerId, users.id))
        .where(eq(items.status, "open"))
        .orderBy(desc(items.createdAt))
        .limit(6),
    ]);

  return {
    total: Number(totalItems[0]?.n ?? 0),
    lost: Number(totalLost[0]?.n ?? 0),
    found: Number(totalFound[0]?.n ?? 0),
    returned: Number(returnedCount[0]?.n ?? 0),
    people: Number(peopleCount[0]?.n ?? 0),
    recent: recentReports,
  };
}

export default async function LandingPage() {
  const data = await getLandingData();
  const me = await currentUser();

  return (
    <div className="min-h-screen bg-canvas">
      {/* ───── Navbar ───── */}
      <header className="sticky top-0 z-40 border-b border-line bg-white/90 backdrop-blur-md">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <Link href="/" aria-label="ReFind home">
            <Wordmark />
          </Link>

          <div className="hidden items-center gap-7 md:flex">
            <a href="#how" className="text-sm font-semibold text-muted hover:text-navy-700 transition-colors">
              How it Works
            </a>
            <a href="#recent" className="text-sm font-semibold text-muted hover:text-navy-700 transition-colors">
              Recent Listings
            </a>
            <a href="#safety" className="text-sm font-semibold text-muted hover:text-navy-700 transition-colors">
              Campus Safety
            </a>
          </div>

          <div className="flex items-center gap-2.5">
            {me ? (
              <Link href="/app">
                <Button size="sm">
                  Dashboard <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            ) : (
              <>
                <Link href="/login" className="hidden sm:block">
                  <Button variant="ghost" size="sm">Sign In</Button>
                </Link>
                <Link href="/signup">
                  <Button size="sm">Get Started</Button>
                </Link>
              </>
            )}
          </div>
        </nav>
      </header>

      {/* ───── Hero Section ───── */}
      <section className="mesh relative overflow-hidden border-b border-line">
        <div className="grid-lines absolute inset-0 opacity-60" aria-hidden />
        <div className="relative mx-auto max-w-6xl px-5 py-20 text-center md:py-28">
          <div className="inline-flex items-center gap-2 mb-6">
            <Badge tone="navy" className="px-3 py-1 text-xs">
              <Sparkles className="h-3.5 w-3.5 text-navy-600" /> Lost it. List it. ReFind it.
            </Badge>
          </div>

          <h1 className="mx-auto max-w-3xl text-4xl font-extrabold leading-[1.08] tracking-tight text-ink sm:text-5xl md:text-6xl">
            Lost Something?{" "}
            <span className="text-navy-700">Let&apos;s ReFind It.</span>
          </h1>

          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted sm:text-lg">
            Report lost belongings, discover possible matches and reconnect people with the things that matter across your college campus.
          </p>

          {/* Instant Search Bar */}
          <form
            action="/app/browse"
            className="mx-auto mt-9 flex max-w-xl items-center gap-2 rounded-2xl border border-line bg-white p-2 shadow-lg shadow-navy-900/5 focus-within:border-navy-400 focus-within:ring-2 focus-within:ring-navy-100 transition-all"
          >
            <span className="pl-3 text-muted">
              <Search className="h-5 w-5 text-navy-500" />
            </span>
            <input
              name="q"
              placeholder="Search for a lost ID card, water bottle, backpack, keys…"
              aria-label="Search listings"
              className="h-11 flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400"
            />
            <Button type="submit" className="shrink-0">
              Search Listings
            </Button>
          </form>

          {/* Quick Report Actions */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Link href="/app/report?kind=lost">
              <Button variant="outline" className="border-red-200 text-red-700 hover:bg-red-50 font-bold">
                <PackageSearch className="h-4 w-4" /> Report Lost Item
              </Button>
            </Link>
            <Link href="/app/report?kind=found">
              <Button variant="outline" className="border-emerald-200 text-emerald-700 hover:bg-emerald-50 font-bold">
                <Handshake className="h-4 w-4" /> Report Found Item
              </Button>
            </Link>
            <Link href="/app/browse">
              <Button variant="soft" className="font-bold">
                Browse All Items
              </Button>
            </Link>
          </div>

          {/* Real-time Community Stats */}
          <dl className="mx-auto mt-14 grid max-w-3xl grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "Lost Reports", value: data.lost, icon: PackageSearch, tone: "text-red-600" },
              { label: "Found Items", value: data.found, icon: Handshake, tone: "text-emerald-600" },
              { label: "Belongings Reunited", value: data.returned, icon: ShieldCheck, tone: "text-amber-600" },
              { label: "Campus Members", value: data.people, icon: Users, tone: "text-navy-600" },
            ].map((s) => (
              <div
                key={s.label}
                className="rounded-2xl border border-line bg-white/85 px-4 py-5 backdrop-blur shadow-sm"
              >
                <s.icon className={`mx-auto mb-2 h-5 w-5 ${s.tone}`} />
                <dd className="text-2xl font-extrabold text-ink">{s.value}</dd>
                <dt className="text-xs font-semibold text-muted mt-0.5">{s.label}</dt>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* ───── How it works ───── */}
      <section id="how" className="mx-auto max-w-6xl px-5 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <Badge tone="navy" className="mb-3">Simplicity &amp; Speed</Badge>
          <h2 className="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
            How ReFind Works
          </h2>
          <p className="mt-3 text-muted">
            Three simple steps to recover what belongs to you.
          </p>
        </div>

        <ol className="mt-12 grid gap-6 md:grid-cols-3">
          {[
            {
              icon: ClipboardList,
              step: "01",
              title: "List Your Report",
              body: "Post what you lost or what you found in under a minute — add a photo, select the campus location, and pick the date.",
            },
            {
              icon: Sparkles,
              step: "02",
              title: "Discover Matches",
              body: "ReFind's intelligent matching compares category, colour, brand, location and timing to suggest likely counterpart reports.",
            },
            {
              icon: MessageCircle,
              step: "03",
              title: "Verify & ReFind It",
              body: "Send a secure verification request. Once approved, a private one-on-one chat opens to arrange the safe handover.",
            },
          ].map((s) => (
            <li key={s.step}>
              <Card className="h-full p-6 border-line hover:border-navy-300 transition-all">
                <div className="flex items-center justify-between">
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-navy-50 text-navy-700">
                    <s.icon className="h-6 w-6" />
                  </span>
                  <span className="text-sm font-extrabold tracking-widest text-navy-200">
                    STEP {s.step}
                  </span>
                </div>
                <h3 className="mt-5 text-lg font-bold text-ink">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{s.body}</p>
              </Card>
            </li>
          ))}
        </ol>
      </section>

      {/* ───── Recent listings ───── */}
      <section id="recent" className="border-y border-line bg-white py-20">
        <div className="mx-auto max-w-6xl px-5">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <Badge tone="navy" className="mb-2">Live Campus Feed</Badge>
              <h2 className="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
                Recently Listed on Campus
              </h2>
              <p className="mt-2 text-muted">
                Active reports from students, faculty, and college staff.
              </p>
            </div>
            <Link href="/app/browse">
              <Button variant="outline">
                Browse All Listings <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          {data.recent.length === 0 ? (
            <Card className="mt-10 p-14 text-center">
              <p className="text-muted">
                No open listings yet — be the first to post a report.
              </p>
            </Card>
          ) : (
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {data.recent.map(({ item, owner }) => (
                <ItemTile key={item.id} item={item} owner={owner} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ───── Privacy & Safety Section ───── */}
      <section id="safety" className="mx-auto max-w-6xl px-5 py-20">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <Badge tone="green" className="mb-4">
              <ShieldCheck className="h-3.5 w-3.5" /> Privacy First
            </Badge>
            <h2 className="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
              Safe &amp; Secure Verification
            </h2>
            <p className="mt-4 leading-relaxed text-muted">
              ReFind never exposes your phone number or email publicly. Anyone who believes an item belongs to them sends a private verification request describing it. Only upon your review and approval does an encrypted private conversation open.
            </p>

            <ul className="mt-7 space-y-3.5">
              {[
                "Personal contact details stay hidden until verification is approved",
                "Private one-on-one in-app chat for handover coordination",
                "Campus-only community of authenticated students, teachers and staff",
                "One-click resolution to mark items returned and close reports",
              ].map((point, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                    <ShieldCheck className="h-3.5 w-3.5" />
                  </span>
                  <span className="text-sm font-medium text-ink">{point}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Interactive Verification Preview Mock */}
          <Card className="overflow-hidden p-0 border-line shadow-md">
            <div className="border-b border-line bg-navy-50/70 px-5 py-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-bold text-navy-900">
                  Verification Request Sample
                </p>
                <p className="text-xs text-muted">on &ldquo;Navy blue steel water bottle&rdquo;</p>
              </div>
              <Badge tone="amber">Pending Approval</Badge>
            </div>
            <div className="space-y-4 p-5 bg-white">
              <div className="rounded-2xl rounded-tl-sm bg-slate-100 px-4 py-3 text-xs leading-relaxed text-ink">
                <p className="font-bold text-slate-800 mb-0.5">Claimant&apos;s Description:</p>
                <p>
                  &ldquo;Hi! I think that bottle is mine — it has a dent near the base and a faded chemistry club sticker on the side from last semester.&rdquo;
                </p>
              </div>

              <div className="ml-auto max-w-[90%] rounded-2xl rounded-tr-sm bg-navy-700 px-4 py-3 text-xs leading-relaxed text-white">
                <p className="font-bold text-navy-100 mb-0.5">Owner Response:</p>
                <p>
                  &ldquo;That matches exactly! Request approved — let&apos;s meet at the Library desk after 4:00 PM.&rdquo;
                </p>
              </div>

              <div className="flex items-center justify-between border-t border-line pt-3 text-xs">
                <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                  <ShieldCheck className="h-4 w-4" />
                  <span>Approved &amp; Chat Unlocked</span>
                </div>
                <span className="text-muted text-[11px]">Handover arranged safely</span>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* ───── Call to Action ───── */}
      <section className="px-5 pb-20">
        <div className="mx-auto max-w-6xl overflow-hidden rounded-3xl bg-navy-700 px-8 py-16 text-center text-white shadow-xl shadow-navy-950/20">
          <Logo size={52} className="mx-auto bg-white/10" />
          <h2 className="mt-6 text-3xl font-extrabold tracking-tight sm:text-4xl">
            Lost it. List it. ReFind it.
          </h2>
          <p className="mx-auto mt-4 max-w-lg text-navy-100 text-sm sm:text-base leading-relaxed">
            Join your campus lost and found community. Publish a report in under a minute and let intelligent matching do the work.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3.5">
            <Link href="/signup">
              <Button
                size="lg"
                className="bg-white text-navy-800 hover:bg-navy-50 font-extrabold shadow-md"
              >
                Create Free Account <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/app/browse">
              <Button
                size="lg"
                variant="outline"
                className="border-white/30 bg-transparent text-white hover:bg-white/10 hover:border-white/60 font-bold"
              >
                Browse All Items
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ───── Footer ───── */}
      <footer className="border-t border-line bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 py-8 sm:flex-row">
          <Wordmark size={30} />
          <p className="text-xs text-muted">
            &copy; {new Date().getFullYear()} ReFind &mdash; &ldquo;Lost it. List it. ReFind it.&rdquo; Built for campus communities.
          </p>
          <div className="flex items-center gap-5 text-xs font-semibold text-muted">
            <Link href="/app/browse" className="hover:text-navy-700 transition-colors">Browse</Link>
            <Link href="/login" className="hover:text-navy-700 transition-colors">Sign In</Link>
            <Link href="/signup" className="hover:text-navy-700 transition-colors">Register</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
