import { listNotifications } from "@/actions/account";
import { requireUser } from "@/lib/session";
import { NotificationList } from "@/components/notification-list";

export const dynamic = "force-dynamic";

export default async function NotificationsPage() {
  const user = await requireUser();
  const items = await listNotifications(user.id);

  return <NotificationList items={items} />;
}
