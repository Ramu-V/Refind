import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Package } from "lucide-react";
import { getThread } from "@/actions/messages";
import { requireUser } from "@/lib/session";
import { Avatar, Badge, Card } from "@/components/ui";
import { Chat } from "@/components/chat";

export const dynamic = "force-dynamic";

export default async function ThreadPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();

  const thread = await getThread(id, user.id);
  if (!thread) notFound();

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-3xl flex-col gap-4">
      <Link
        href="/app/messages"
        className="inline-flex w-fit items-center gap-2 text-sm font-semibold text-muted hover:text-navy-700"
      >
        <ArrowLeft className="h-4 w-4" /> All messages
      </Link>

      <Card className="flex min-h-0 flex-1 flex-col overflow-hidden p-0">
        {/* Thread header */}
        <div className="flex items-center gap-3 border-b border-line px-5 py-4">
          <Avatar
            name={thread.partner.name}
            accent={thread.partner.accent}
            size={40}
          />
          <div className="min-w-0 flex-1">
            <p className="truncate font-bold text-ink">{thread.partner.name}</p>
            <p className="truncate text-[13px] capitalize text-muted">
              {thread.partner.role}
              {thread.partner.department ? ` · ${thread.partner.department}` : ""}
            </p>
          </div>
          <Link
            href={`/app/items/${thread.item.id}`}
            className="hidden sm:block"
          >
            <Badge tone="navy">
              <Package className="h-3 w-3" />
              {thread.item.title}
            </Badge>
          </Link>
        </div>

        <Chat
          claimId={id}
          initial={thread.messages}
          me={{
            id: user.id,
            name: user.name ?? "You",
            accent: user.accent ?? "#1e3a8a",
          }}
        />
      </Card>
    </div>
  );
}
