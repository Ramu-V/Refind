import Link from "next/link";
import { MessageCircle } from "lucide-react";
import { threadsFor } from "@/actions/messages";
import { requireUser } from "@/lib/session";
import { Avatar, Badge, Button, Card, Empty } from "@/components/ui";
import { timeAgo } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function MessagesPage() {
  const user = await requireUser();
  const threads = await threadsFor(user.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-ink">
          Messages
        </h1>
        <p className="mt-1 text-sm text-muted">
          Private chats, opened once a verification request is approved.
        </p>
      </div>

      {threads.length === 0 ? (
        <Empty
          icon={MessageCircle}
          title="No conversations yet"
          text="When you approve a request — or yours gets approved — a private chat opens here so you can arrange the handover."
          action={
            <Link href="/app/requests">
              <Button variant="outline">View requests</Button>
            </Link>
          }
        />
      ) : (
        <Card className="divide-y divide-line overflow-hidden p-0">
          {threads.map((t) => (
            <Link
              key={t.claim.id}
              href={`/app/messages/${t.claim.id}`}
              className="flex items-center gap-4 p-4 transition-colors hover:bg-navy-50/50"
            >
              <Avatar name={t.partner.name} accent={t.partner.accent} size={44} />

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="truncate font-bold text-ink">{t.partner.name}</p>
                  <Badge tone={t.item.kind === "lost" ? "red" : "green"}>
                    {t.item.kind}
                  </Badge>
                </div>
                <p className="truncate text-[13px] font-semibold text-navy-700">
                  {t.item.title}
                </p>
                <p className="truncate text-[13px] text-muted">
                  {t.lastMessage ? t.lastMessage.body : "No messages yet — say hello"}
                </p>
              </div>

              <div className="flex shrink-0 flex-col items-end gap-1.5">
                {t.lastMessage && (
                  <span className="text-[11px] text-slate-400">
                    {timeAgo(t.lastMessage.createdAt)}
                  </span>
                )}
                {t.unread > 0 && (
                  <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-navy-700 px-1.5 text-[11px] font-bold text-white">
                    {t.unread}
                  </span>
                )}
              </div>
            </Link>
          ))}
        </Card>
      )}
    </div>
  );
}
