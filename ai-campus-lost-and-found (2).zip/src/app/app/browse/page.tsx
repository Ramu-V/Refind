import Link from "next/link";
import {
  CalendarDays,
  Filter,
  PackageSearch,
  PlusCircle,
  RotateCcw,
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { searchItems } from "@/actions/items";
import { CATEGORIES, CAMPUS_SPOTS, COLORS } from "@/lib/constants";
import { Badge, Button, Card, Empty, Input, Select } from "@/components/ui";
import { ItemTile } from "@/components/item-tile";

export const dynamic = "force-dynamic";

type SP = Record<string, string | string[] | undefined>;

function one(v: string | string[] | undefined) {
  return typeof v === "string" ? v : "";
}

export default async function BrowsePage({
  searchParams,
}: {
  searchParams: Promise<SP>;
}) {
  const sp = await searchParams;
  const q = one(sp.q);
  const kind = one(sp.kind);
  const category = one(sp.category);
  const location = one(sp.location);
  const color = one(sp.color);
  const status = one(sp.status);
  const fromDate = one(sp.fromDate);
  const toDate = one(sp.toDate);
  const sort = one(sp.sort) || "newest";

  const rows = await searchItems({
    q,
    kind,
    category,
    location,
    color,
    status,
    fromDate,
    toDate,
    sort,
  });

  const activeFilters = [
    q && `Keyword: "${q}"`,
    kind && `Type: ${kind}`,
    category && `Category: ${category}`,
    location && `Location: ${location}`,
    color && `Color: ${color}`,
    status && `Status: ${status}`,
    fromDate && `From: ${fromDate}`,
    toDate && `To: ${toDate}`,
  ].filter(Boolean) as string[];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">
            Browse Lost &amp; Found
          </h1>
          <p className="mt-1 text-sm text-muted">
            {rows.length} report{rows.length === 1 ? "" : "s"} found across campus
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link href="/app/report?kind=lost">
            <Button variant="outline" size="sm" className="border-red-200 text-red-700 hover:bg-red-50">
              Report Lost
            </Button>
          </Link>
          <Link href="/app/report?kind=found">
            <Button variant="outline" size="sm" className="border-emerald-200 text-emerald-700 hover:bg-emerald-50">
              Report Found
            </Button>
          </Link>
          <Link href="/app/report">
            <Button size="sm">
              <PlusCircle className="h-4 w-4" /> Report an Item
            </Button>
          </Link>
        </div>
      </div>

      {/* Filter and Search Box */}
      <Card className="p-4 sm:p-5">
        <form method="GET" className="space-y-3.5">
          {/* Main search row */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
              <Input
                name="q"
                defaultValue={q}
                placeholder="Search by title, brand, description, location…"
                className="pl-10"
                aria-label="Search listings"
              />
            </div>
            <div className="flex items-center gap-2">
              <Select name="sort" defaultValue={sort} className="w-40" aria-label="Sort order">
                <option value="newest">Newest first</option>
                <option value="oldest">Oldest first</option>
                <option value="date_desc">Date: Recent</option>
                <option value="date_asc">Date: Earliest</option>
              </Select>
              <Button type="submit">
                <Search className="h-4 w-4" /> Search
              </Button>
            </div>
          </div>

          {/* Filter selectors grid */}
          <div className="grid gap-2.5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 pt-1">
            <Select name="kind" defaultValue={kind} aria-label="Report type">
              <option value="">All Types (Lost &amp; Found)</option>
              <option value="lost">Lost only</option>
              <option value="found">Found only</option>
            </Select>

            <Select name="category" defaultValue={category} aria-label="Category">
              <option value="">All Categories</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>

            <Select name="location" defaultValue={location} aria-label="Campus location">
              <option value="">All Campus Locations</option>
              {CAMPUS_SPOTS.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </Select>

            <Select name="color" defaultValue={color} aria-label="Color">
              <option value="">All Colours</option>
              {COLORS.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>

            <Select name="status" defaultValue={status} aria-label="Status">
              <option value="">All Statuses</option>
              <option value="open">Open (Active)</option>
              <option value="claimed">Claimed</option>
              <option value="returned">Returned</option>
              <option value="closed">Closed</option>
            </Select>
          </div>

          {/* Date range row */}
          <div className="flex flex-wrap items-center gap-3 pt-1 border-t border-line text-xs text-muted">
            <span className="font-semibold text-slate-700 flex items-center gap-1">
              <CalendarDays className="h-3.5 w-3.5 text-navy-600" /> Date range:
            </span>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">From:</span>
              <Input
                name="fromDate"
                type="date"
                defaultValue={fromDate}
                className="h-8 px-2 py-1 text-xs w-36"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">To:</span>
              <Input
                name="toDate"
                type="date"
                defaultValue={toDate}
                className="h-8 px-2 py-1 text-xs w-36"
              />
            </div>

            <div className="ml-auto flex items-center gap-2">
              {activeFilters.length > 0 && (
                <Link
                  href="/app/browse"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-red-600 hover:text-red-700 hover:underline px-2 py-1"
                >
                  <RotateCcw className="h-3 w-3" /> Reset filters
                </Link>
              )}
            </div>
          </div>
        </form>

        {/* Active Filter Pills */}
        {activeFilters.length > 0 && (
          <div className="mt-3.5 flex flex-wrap items-center gap-1.5 border-t border-line pt-3">
            <span className="text-xs font-bold text-muted mr-1">Active filters:</span>
            {activeFilters.map((f, i) => (
              <span
                key={i}
                className="inline-flex items-center gap-1 rounded-lg bg-navy-50 text-navy-800 px-2.5 py-1 text-xs font-medium"
              >
                {f}
              </span>
            ))}
          </div>
        )}
      </Card>

      {/* Item Results Grid */}
      {rows.length === 0 ? (
        <Empty
          icon={PackageSearch}
          title="No reports match your search criteria"
          text="Try adjusting your keywords or clearing some filters to see more listings."
          action={
            <div className="flex gap-2">
              <Link href="/app/browse">
                <Button variant="outline">Clear all filters</Button>
              </Link>
              <Link href="/app/report">
                <Button>
                  <PlusCircle className="h-4 w-4" /> Report an Item
                </Button>
              </Link>
            </div>
          }
        />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map(({ item, owner }) => (
            <ItemTile key={item.id} item={item} owner={owner} />
          ))}
        </div>
      )}
    </div>
  );
}
