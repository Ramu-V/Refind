import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  CalendarDays,
  Check,
  CheckCircle2,
  Info,
  MapPin,
  MessageCircle,
  Palette,
  Phone,
  ShieldCheck,
  Sparkles,
  Tag as TagIcon,
  UserCheck,
} from "lucide-react";
import { getItem, suggestionsFor } from "@/actions/items";
import { claimsOnItem } from "@/actions/claims";
import { requireUser } from "@/lib/session";
import { Avatar, Badge, Button, Card, CardHead } from "@/components/ui";
import { ClaimForm, ClaimReview, OwnerControls } from "@/components/item-actions";
import { ItemTile } from "@/components/item-tile";
import { ReportImage } from "@/components/report-image";
import { formatDate, timeAgo } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ItemDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();

  const row = await getItem(id);
  if (!row) notFound();

  const { item, owner } = row;
  const isOwner = item.ownerId === user.id;

  const [claims, suggestions] = await Promise.all([
    isOwner ? claimsOnItem(item.id) : Promise.resolve([]),
    suggestionsFor(item.id),
  ]);

  const pendingCount = claims.filter((c) => c.claim.status === "pending").length;
  const isLost = item.kind === "lost";

  const facts = [
    { icon: TagIcon, label: "Category", value: item.category },
    {
      icon: MapPin,
      label: isLost ? "Lost at" : "Found at",
      value: item.campusArea ? `${item.location} (${item.campusArea})` : item.location,
    },
    {
      icon: CalendarDays,
      label: isLost ? "Date lost" : "Date found",
      value: formatDate(item.occurredOn),
    },
    ...(item.color ? [{ icon: Palette, label: "Primary Colour", value: item.color }] : []),
    ...(item.brand ? [{ icon: Info, label: "Brand / Model", value: item.brand }] : []),
    ...(item.preferredContact
      ? [
          {
            icon: Phone,
            label: "Preferred Contact",
            value:
              item.preferredContact === "chat"
                ? "In-app ReFind chat"
                : item.preferredContact === "phone"
                ? "Phone (upon verification)"
                : item.preferredContact === "email"
                ? "College email (upon verification)"
                : item.preferredContact,
          },
        ]
      : []),
  ];

  return (
    <div className="space-y-6">
      <Link
        href="/app/browse"
        className="inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-navy-700"
      >
        <ArrowLeft className="h-4 w-4" /> Back to browse
      </Link>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Column */}
        <div className="space-y-6 lg:col-span-2">
          <Card className="overflow-hidden border-line">
            {/* Main Photo Banner */}
            <div className="relative aspect-[16/9] bg-navy-50 overflow-hidden">
              <ReportImage
                src={item.imageUrl}
                alt={item.title}
                fallbackClassName="gap-2"
              />

              <div className="absolute left-4 top-4 flex flex-wrap gap-2">
                <Badge tone={isLost ? "red" : "green"}>
                  {isLost ? "Lost Item Report" : "Found Item Report"}
                </Badge>
                {item.status === "returned" && (
                  <Badge tone="green">Returned to Owner</Badge>
                )}
                {item.status === "claimed" && (
                  <Badge tone="amber">Claimed</Badge>
                )}
                {item.status === "closed" && (
                  <Badge tone="slate">Closed</Badge>
                )}
              </div>
            </div>

            {/* Description & Metadata */}
            <div className="p-6">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-navy-600">
                  {item.category}
                </span>
                <span className="text-xs text-muted">
                  Reported {timeAgo(item.createdAt)}
                </span>
              </div>

              <h1 className="mt-2 text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">
                {item.title}
              </h1>

              <div className="mt-5 space-y-2">
                <h3 className="text-xs font-bold uppercase tracking-wide text-slate-500">
                  Description
                </h3>
                <p className="leading-relaxed text-ink text-sm sm:text-base whitespace-pre-line bg-slate-50/60 p-4 rounded-xl border border-line">
                  {item.description}
                </p>
              </div>

              {/* Facts Grid */}
              <div className="mt-6 border-t border-line pt-5">
                <h3 className="text-xs font-bold uppercase tracking-wide text-slate-500 mb-3">
                  Report Details
                </h3>
                <dl className="grid gap-4 sm:grid-cols-2">
                  {facts.map((f) => (
                    <div
                      key={f.label}
                      className="flex items-start gap-3 rounded-xl border border-line p-3 bg-white"
                    >
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-navy-50 text-navy-600 mt-0.5">
                        <f.icon className="h-4 w-4" />
                      </span>
                      <div className="min-w-0">
                        <dt className="text-[11px] font-bold uppercase tracking-wide text-muted">
                          {f.label}
                        </dt>
                        <dd className="text-sm font-semibold text-ink truncate mt-0.5">
                          {f.value}
                        </dd>
                      </div>
                    </div>
                  ))}
                </dl>
              </div>
            </div>
          </Card>

          {/* Owner verification requests review */}
          {isOwner && (
            <Card className="border-line">
              <CardHead
                title="Verification &amp; Claim Requests"
                subtitle={
                  claims.length === 0
                    ? "No requests received yet."
                    : `${claims.length} request${claims.length === 1 ? "" : "s"}${
                        pendingCount ? ` · ${pendingCount} awaiting your approval` : ""
                      }`
                }
              />
              <div className="p-5">
                {claims.length === 0 ? (
                  <p className="py-8 text-center text-sm text-muted">
                    When someone sends a verification request for this item, their details and proof will appear here for you to approve.
                  </p>
                ) : (
                  <div className="space-y-4">
                    {claims.map(({ claim, claimant }) => (
                      <ClaimReview key={claim.id} claim={claim} claimant={claimant} />
                    ))}
                  </div>
                )}
              </div>
            </Card>
          )}

          {/* AI Suggested Matches for this specific item */}
          {suggestions.length > 0 && (
            <section className="space-y-4 pt-2">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-navy-700 text-white text-xs">
                  <Sparkles className="h-3.5 w-3.5" />
                </span>
                <h2 className="text-lg font-extrabold tracking-tight text-ink">
                  Potential Matches for this Report
                </h2>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {suggestions.map((s) => (
                  <div key={s.item.id} className="relative">
                    <span className="absolute right-3 top-3 z-10 rounded-full bg-navy-900/90 backdrop-blur px-2.5 py-1 text-[11px] font-bold text-white shadow">
                      {s.score}% Match
                    </span>
                    <ItemTile item={s.item} owner={s.owner} matchScore={s.score} />
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Author info */}
          <Card className="border-line">
            <CardHead title={isLost ? "Reported Lost by" : "Found by"} />
            <div className="p-5 space-y-4">
              <div className="flex items-center gap-3">
                <Avatar name={owner.name} accent={owner.accent} size={46} />
                <div className="min-w-0">
                  <p className="font-bold text-ink text-base">{owner.name}</p>
                  <p className="text-xs capitalize text-muted">
                    {owner.role}
                    {owner.department ? ` · ${owner.department}` : ""}
                  </p>
                </div>
              </div>

              {owner.bio && (
                <p className="text-xs text-muted leading-relaxed border-t border-line pt-3">
                  {owner.bio}
                </p>
              )}

              <div className="rounded-xl bg-navy-50/70 p-3.5 text-xs text-muted space-y-1.5 border border-navy-100">
                <p className="font-bold text-navy-900 flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-600" />
                  Privacy Protection
                </p>
                <p>
                  Contact information is kept secure. Private conversation opens only after a verification request is reviewed and approved.
                </p>
              </div>
            </div>
          </Card>

          {/* Action cards: Owner vs Non-Owner */}
          {isOwner ? (
            <OwnerControls item={item} />
          ) : item.status === "returned" ? (
            <Card className="border-emerald-200 bg-emerald-50/50 p-5 text-center space-y-2">
              <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-600" />
              <h4 className="font-bold text-ink">Item Already Returned</h4>
              <p className="text-xs text-muted">
                This item has been successfully reunited with its rightful owner.
              </p>
            </Card>
          ) : item.status === "closed" ? (
            <Card className="p-5 text-center space-y-2">
              <h4 className="font-bold text-ink">Listing Closed</h4>
              <p className="text-xs text-muted">
                This report is currently closed by the owner.
              </p>
            </Card>
          ) : (
            <ClaimForm item={item} />
          )}
        </div>
      </div>
    </div>
  );
}
