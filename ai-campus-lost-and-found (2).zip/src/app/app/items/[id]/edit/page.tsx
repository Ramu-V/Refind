import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { items } from "@/db/schema";
import { requireUser } from "@/lib/session";
import { ItemForm } from "@/components/item-form";

export const dynamic = "force-dynamic";

export default async function EditItemPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();

  const [item] = await db.select().from(items).where(eq(items.id, id)).limit(1);
  if (!item) notFound();
  if (item.ownerId !== user.id) redirect(`/app/items/${id}`);

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Link
        href={`/app/items/${id}`}
        className="inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-navy-700"
      >
        <ArrowLeft className="h-4 w-4" /> Back to listing
      </Link>

      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-ink">
          Edit listing
        </h1>
        <p className="mt-1 text-sm text-muted">
          Update the details of &ldquo;{item.title}&rdquo;.
        </p>
      </div>

      <ItemForm mode="edit" item={item} />
    </div>
  );
}
