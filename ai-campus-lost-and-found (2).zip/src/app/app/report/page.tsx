import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { ItemForm } from "@/components/item-form";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function ReportPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requireUser();
  const sp = await searchParams;
  const kindParam = typeof sp.kind === "string" ? sp.kind : "lost";
  const defaultKind = kindParam === "found" ? "found" : "lost";

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Link
        href="/app/browse"
        className="inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-navy-700"
      >
        <ArrowLeft className="h-4 w-4" /> Back to browse
      </Link>

      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-ink">
          Report an item
        </h1>
        <p className="mt-1 text-sm text-muted">
          Give as much detail as you can — it dramatically improves the chance of
          a match.
        </p>
      </div>

      <ItemForm mode="create" defaultKind={defaultKind} />
    </div>
  );
}
