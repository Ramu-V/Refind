import Link from "next/link";
import {
  ArrowRight,
  CalendarDays,
  Check,
  Eye,
  Handshake,
  MapPin,
  PackageSearch,
  PlusCircle,
  Send,
  Sparkles,
  Tag,
} from "lucide-react";
import { getUserMatches } from "@/actions/items";
import { requireUser } from "@/lib/session";
import { Badge, Button, Card, CardHead, Empty, Avatar } from "@/components/ui";
import { formatDate, timeAgo } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function MatchesPage() {
  const user = await requireUser();
  const matchesList = await getUserMatches(user.id);

  return (
    <div className="space-y-7">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-navy-50 text-navy-600">
              <Sparkles className="h-4 w-4" />
            </span>
            <h1 className="text-2xl font-extrabold tracking-tight text-ink">
              Potential Matches
            </h1>
          </div>
          <p className="mt-1 text-sm text-muted">
            Intelligent matches detected between your listings and other reports across campus.
          </p>
        </div>

        <Link href="/app/report">
          <Button variant="outline">
            <PlusCircle className="h-4 w-4" /> Report an Item
          </Button>
        </Link>
      </div>

      {matchesList.length === 0 ? (
        <Empty
          icon={Sparkles}
          title="No potential matches found yet"
          text="When items with matching categories, colours, locations, or descriptions are reported, they will automatically appear here."
          action={
            <div className="flex gap-2">
              <Link href="/app/browse">
                <Button variant="outline">Browse all listings</Button>
              </Link>
              <Link href="/app/report">
                <Button>Report an item</Button>
              </Link>
            </div>
          }
        />
      ) : (
        <div className="space-y-5">
          {matchesList.map((m) => {
            const isMyLost = m.lostItem.ownerId === user.id;
            const isMyFound = m.foundItem.ownerId === user.id;
            const score = m.match.score;
            const scoreColor =
              score >= 70
                ? "bg-emerald-50 text-emerald-700 ring-emerald-200 border-emerald-200"
                : score >= 50
                ? "bg-amber-50 text-amber-700 ring-amber-200 border-amber-200"
                : "bg-navy-50 text-navy-700 ring-navy-200 border-navy-200";

            const signals = (m.match.signals ?? {}) as {
              categoryMatch?: boolean;
              colorMatch?: boolean;
              brandMatch?: boolean;
              locationMatch?: boolean;
              dateProximityDays?: number;
              keywordOverlap?: string[];
            };

            return (
              <Card key={m.match.id} className="overflow-hidden p-0 border border-line hover:border-navy-200 transition-all">
                {/* Header banner */}
                <div className="flex flex-wrap items-center justify-between gap-3 bg-navy-50/60 px-5 py-3 border-b border-line">
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-navy-700 text-white text-xs font-extrabold">
                      AI
                    </span>
                    <span className="text-sm font-bold text-ink">
                      {isMyLost ? "Match for your Lost item" : isMyFound ? "Match for your Found item" : "Campus Cross-Match"}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold ring-1 ring-inset ${scoreColor}`}>
                      <Sparkles className="h-3 w-3" />
                      {score}% Similarity Score
                    </span>
                  </div>
                </div>

                <div className="p-5 space-y-5">
                  {/* Pair comparison columns */}
                  <div className="grid gap-4 md:grid-cols-2">
                    {/* Lost side */}
                    <div className="rounded-2xl border border-line bg-white p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <Badge tone="red">
                          <PackageSearch className="h-3 w-3" /> Lost Report
                        </Badge>
                        {isMyLost && (
                          <span className="text-[11px] font-bold text-navy-700 bg-navy-50 px-2 py-0.5 rounded-md">
                            Your listing
                          </span>
                        )}
                      </div>

                      <div>
                        <h4 className="font-bold text-ink text-base">{m.lostItem.title}</h4>
                        <p className="mt-1 text-xs text-muted line-clamp-2">{m.lostItem.description}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 pt-2 border-t border-line">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5 text-navy-500" />
                          <span className="truncate">{m.lostItem.location}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <CalendarDays className="h-3.5 w-3.5 text-slate-400" />
                          <span>{formatDate(m.lostItem.occurredOn)}</span>
                        </span>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-2">
                          <Avatar name={m.lostOwner.name} accent={m.lostOwner.accent} size={22} />
                          <span className="text-xs text-muted truncate max-w-[120px]">{m.lostOwner.name}</span>
                        </div>
                        <Link
                          href={`/app/items/${m.lostItem.id}`}
                          className="text-xs font-bold text-navy-700 hover:underline flex items-center gap-0.5"
                        >
                          View report <ArrowRight className="h-3 w-3" />
                        </Link>
                      </div>
                    </div>

                    {/* Found side */}
                    <div className="rounded-2xl border border-line bg-white p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <Badge tone="green">
                          <Handshake className="h-3 w-3" /> Found Report
                        </Badge>
                        {isMyFound && (
                          <span className="text-[11px] font-bold text-navy-700 bg-navy-50 px-2 py-0.5 rounded-md">
                            Your listing
                          </span>
                        )}
                      </div>

                      <div>
                        <h4 className="font-bold text-ink text-base">{m.foundItem.title}</h4>
                        <p className="mt-1 text-xs text-muted line-clamp-2">{m.foundItem.description}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 pt-2 border-t border-line">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5 text-navy-500" />
                          <span className="truncate">{m.foundItem.location}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <CalendarDays className="h-3.5 w-3.5 text-slate-400" />
                          <span>{formatDate(m.foundItem.occurredOn)}</span>
                        </span>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-2">
                          <Avatar name={m.foundOwner.name} accent={m.foundOwner.accent} size={22} />
                          <span className="text-xs text-muted truncate max-w-[120px]">{m.foundOwner.name}</span>
                        </div>
                        <Link
                          href={`/app/items/${m.foundItem.id}`}
                          className="text-xs font-bold text-navy-700 hover:underline flex items-center gap-0.5"
                        >
                          View report <ArrowRight className="h-3 w-3" />
                        </Link>
                      </div>
                    </div>
                  </div>

                  {/* Matching Signals Breakdown */}
                  <div className="rounded-xl bg-slate-50 p-4 border border-line">
                    <p className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-2.5">
                      Why this was matched
                    </p>
                    <p className="text-xs text-ink leading-relaxed mb-3">{m.match.explanation}</p>

                    <div className="flex flex-wrap gap-2 text-xs">
                      {signals.categoryMatch && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-medium">
                          <Check className="h-3 w-3" /> Same Category ({m.lostItem.category})
                        </span>
                      )}
                      {signals.colorMatch && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-medium">
                          <Check className="h-3 w-3" /> Same Colour ({m.lostItem.color})
                        </span>
                      )}
                      {signals.brandMatch && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-medium">
                          <Check className="h-3 w-3" /> Same Brand ({m.lostItem.brand})
                        </span>
                      )}
                      {signals.locationMatch && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-medium">
                          <Check className="h-3 w-3" /> Same Location ({m.lostItem.location})
                        </span>
                      )}
                      {signals.dateProximityDays !== undefined && signals.dateProximityDays <= 3 && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-100 text-blue-800 font-medium">
                          <Check className="h-3 w-3" /> Within {signals.dateProximityDays === 0 ? "same day" : `${signals.dateProximityDays} days`}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions footer */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    <p className="text-xs text-muted">
                      Matched {timeAgo(m.match.createdAt)}
                    </p>

                    <div className="flex items-center gap-2">
                      {isMyLost ? (
                        <Link href={`/app/items/${m.foundItem.id}`}>
                          <Button size="sm">
                            <Send className="h-3.5 w-3.5" /> Send Verification Request
                          </Button>
                        </Link>
                      ) : isMyFound ? (
                        <Link href={`/app/items/${m.lostItem.id}`}>
                          <Button size="sm">
                            <Send className="h-3.5 w-3.5" /> Contact Owner
                          </Button>
                        </Link>
                      ) : (
                        <Link href={`/app/items/${m.lostItem.id}`}>
                          <Button size="sm" variant="outline">
                            <Eye className="h-3.5 w-3.5" /> Inspect Match
                          </Button>
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
