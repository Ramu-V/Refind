import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { PlusCircle, Tag } from "lucide-react";
import { db } from "@/db";
import { items, users } from "@/db/schema";
import { requireUser } from "@/lib/session";
import { Badge, Button, Empty } from "@/components/ui";
import { ItemTile } from "@/components/item-tile";

export const dynamic = "force-dynamic";

export default async function MyItemsPage() {
  const user = await requireUser();

  const rows = await db
    .select({ item: items, owner: users })
    .from(items)
    .innerJoin(users, eq(items.ownerId, users.id))
    .where(eq(items.ownerId, user.id))
    .orderBy(desc(items.createdAt));

  const open = rows.filter((r) => r.item.status === "open");
  const claimed = rows.filter((r) => r.item.status === "claimed");
  const returned = rows.filter((r) => r.item.status === "returned");

  const groups = [
    { title: "Open", rows: open, tone: "navy" as const },
    { title: "Claimed", rows: claimed, tone: "amber" as const },
    { title: "Returned", rows: returned, tone: "green" as const },
  ].filter((g) => g.rows.length > 0);

  return (
    <div className="space-y-7">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-ink">
            My listings
          </h1>
          <p className="mt-1 text-sm text-muted">
            Everything you&apos;ve reported lost or found.
          </p>
        </div>
        <Link href="/app/report">
          <Button>
            <PlusCircle className="h-4 w-4" /> Report an item
          </Button>
        </Link>
      </div>

      {rows.length === 0 ? (
        <Empty
          icon={Tag}
          title="You haven't listed anything yet"
          text="Report something you've lost, or post an item you found so its owner can reach you."
          action={
            <Link href="/app/report">
              <Button>
                <PlusCircle className="h-4 w-4" /> Report an item
              </Button>
            </Link>
          }
        />
      ) : (
        groups.map((g) => (
          <section key={g.title}>
            <div className="mb-4 flex items-center gap-2.5">
              <h2 className="text-lg font-extrabold tracking-tight text-ink">
                {g.title}
              </h2>
              <Badge tone={g.tone}>{g.rows.length}</Badge>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {g.rows.map(({ item, owner }) => (
                <ItemTile key={item.id} item={item} owner={owner} />
              ))}
            </div>
          </section>
        ))
      )}
    </div>
  );
}
