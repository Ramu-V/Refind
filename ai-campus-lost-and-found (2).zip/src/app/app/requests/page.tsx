import Link from "next/link";
import { Inbox, Send } from "lucide-react";
import { incomingClaims, outgoingClaims } from "@/actions/claims";
import { requireUser } from "@/lib/session";
import { Badge, Button, Card, CardHead, Empty } from "@/components/ui";
import { ClaimReview } from "@/components/item-actions";
import { timeAgo } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function RequestsPage() {
  const user = await requireUser();

  const [incoming, outgoing] = await Promise.all([
    incomingClaims(user.id),
    outgoingClaims(user.id),
  ]);

  const pending = incoming.filter((r) => r.claim.status === "pending");
  const handled = incoming.filter((r) => r.claim.status !== "pending");

  return (
    <div className="space-y-7">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-ink">
          Requests
        </h1>
        <p className="mt-1 text-sm text-muted">
          Verification requests on your listings, and the ones you&apos;ve sent.
        </p>
      </div>

      {/* Incoming */}
      <Card>
        <CardHead
          title="Received"
          subtitle="People responding to items you posted"
          action={
            pending.length > 0 ? (
              <Badge tone="amber">{pending.length} pending</Badge>
            ) : undefined
          }
        />
        <div className="p-5">
          {incoming.length === 0 ? (
            <div className="py-10 text-center">
              <Inbox className="mx-auto h-9 w-9 text-navy-200" />
              <p className="mt-3 text-sm font-semibold text-ink">
                No requests yet
              </p>
              <p className="mt-1 text-[13px] text-muted">
                When someone responds to one of your listings, it&apos;ll show up
                here.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {pending.length > 0 && (
                <div className="space-y-3">
                  {pending.map(({ claim, item, claimant }) => (
                    <div key={claim.id}>
                      <Link
                        href={`/app/items/${item.id}`}
                        className="mb-2 inline-block text-[13px] font-bold text-navy-700 hover:underline"
                      >
                        {item.title} →
                      </Link>
                      <ClaimReview claim={claim} claimant={claimant} />
                    </div>
                  ))}
                </div>
              )}

              {handled.length > 0 && (
                <div>
                  {pending.length > 0 && (
                    <p className="mb-3 border-t border-line pt-5 text-[11px] font-bold uppercase tracking-wide text-muted">
                      Already handled
                    </p>
                  )}
                  <div className="space-y-3">
                    {handled.map(({ claim, item, claimant }) => (
                      <div key={claim.id}>
                        <Link
                          href={`/app/items/${item.id}`}
                          className="mb-2 inline-block text-[13px] font-bold text-navy-700 hover:underline"
                        >
                          {item.title} →
                        </Link>
                        <ClaimReview claim={claim} claimant={claimant} />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </Card>

      {/* Outgoing */}
      <Card>
        <CardHead title="Sent" subtitle="Requests you've made on other listings" />
        <div className="p-5">
          {outgoing.length === 0 ? (
            <div className="py-10 text-center">
              <Send className="mx-auto h-9 w-9 text-navy-200" />
              <p className="mt-3 text-sm font-semibold text-ink">
                You haven&apos;t sent any requests
              </p>
              <p className="mt-1 text-[13px] text-muted">
                Found something of yours in the listings? Send a request.
              </p>
              <Link href="/app/browse" className="mt-5 inline-block">
                <Button variant="outline" size="sm">Browse items</Button>
              </Link>
            </div>
          ) : (
            <ul className="space-y-3">
              {outgoing.map(({ claim, item, owner }) => (
                <li
                  key={claim.id}
                  className="flex flex-wrap items-center gap-3 rounded-xl border border-line p-4"
                >
                  <div className="min-w-0 flex-1">
                    <Link
                      href={`/app/items/${item.id}`}
                      className="font-bold text-ink hover:text-navy-700 hover:underline"
                    >
                      {item.title}
                    </Link>
                    <p className="mt-0.5 text-[13px] text-muted">
                      Posted by {owner.name} · sent {timeAgo(claim.createdAt)}
                    </p>
                    <p className="mt-2 line-clamp-2 text-[13px] text-muted">
                      &ldquo;{claim.message}&rdquo;
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {claim.status === "pending" && <Badge tone="amber">Pending</Badge>}
                    {claim.status === "declined" && <Badge tone="slate">Declined</Badge>}
                    {claim.status === "approved" && (
                      <>
                        <Badge tone="green">Approved</Badge>
                        <Link href={`/app/messages/${claim.id}`}>
                          <Button size="sm" variant="outline">Open chat</Button>
                        </Link>
                      </>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </Card>
    </div>
  );
}
