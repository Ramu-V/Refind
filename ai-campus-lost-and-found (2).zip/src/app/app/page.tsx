import Link from "next/link";
import { and, desc, eq, ne, or } from "drizzle-orm";
import {
  ArrowRight,
  Bell,
  CheckCircle2,
  ClipboardList,
  Compass,
  Handshake,
  Inbox,
  PackageSearch,
  PlusCircle,
  Sparkles,
  Tag,
} from "lucide-react";
import { db } from "@/db";
import { claims, items, matches, notifications, users } from "@/db/schema";
import { requireUser } from "@/lib/session";
import { getUserMatches } from "@/actions/items";
import { Badge, Button, Card, CardHead, Empty, Avatar } from "@/components/ui";
import { ItemTile } from "@/components/item-tile";
import { formatDate, timeAgo } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function OverviewPage() {
  const user = await requireUser();

  const [
    allItems,
    myItems,
    pendingRequests,
    recentFeed,
    recentNotifs,
    userMatches,
  ] = await Promise.all([
    db.select().from(items),
    db.select().from(items).where(eq(items.ownerId, user.id)),
    db
      .select({ claim: claims, item: items, claimant: users })
      .from(claims)
      .innerJoin(items, eq(claims.itemId, items.id))
      .innerJoin(users, eq(claims.claimantId, users.id))
      .where(and(eq(items.ownerId, user.id), eq(claims.status, "pending")))
      .orderBy(desc(claims.createdAt))
      .limit(3),
    db
      .select({ item: items, owner: users })
      .from(items)
      .innerJoin(users, eq(items.ownerId, users.id))
      .where(eq(items.status, "open"))
      .orderBy(desc(items.createdAt))
      .limit(3),
    db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, user.id))
      .orderBy(desc(notifications.createdAt))
      .limit(5),
    getUserMatches(user.id),
  ]);

  const totalLost = allItems.filter((i) => i.kind === "lost").length;
  const totalFound = allItems.filter((i) => i.kind === "found").length;
  const totalReturned = allItems.filter((i) => i.status === "returned").length;

  const stats = [
    {
      label: "Campus Lost Reports",
      value: totalLost,
      icon: PackageSearch,
      tone: "bg-red-50 text-red-600",
      sub: `${myItems.filter((i) => i.kind === "lost").length} reported by you`,
    },
    {
      label: "Campus Found Items",
      value: totalFound,
      icon: Handshake,
      tone: "bg-emerald-50 text-emerald-600",
      sub: `${myItems.filter((i) => i.kind === "found").length} reported by you`,
    },
    {
      label: "Potential Matches",
      value: userMatches.length,
      icon: Sparkles,
      tone: "bg-navy-50 text-navy-600",
      sub: "Active AI suggestions",
    },
    {
      label: "Belongings Reunited",
      value: totalReturned,
      icon: CheckCircle2,
      tone: "bg-amber-50 text-amber-600",
      sub: "Successfully returned",
    },
  ];

  const firstName = (user.name ?? "there").split(" ")[0];

  return (
    <div className="space-y-8">
      {/* Greeting and Quick Actions */}
      <section className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">
            Welcome back, {firstName}
          </h1>
          <p className="mt-1 text-sm text-muted">
            Lost it. List it. ReFind it. Here is your campus lost &amp; found overview.
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <Link href="/app/report?kind=lost">
            <Button variant="outline" className="border-red-200 hover:bg-red-50 text-red-700">
              <PackageSearch className="h-4 w-4" /> Report Lost
            </Button>
          </Link>
          <Link href="/app/report?kind=found">
            <Button variant="outline" className="border-emerald-200 hover:bg-emerald-50 text-emerald-700">
              <Handshake className="h-4 w-4" /> Report Found
            </Button>
          </Link>
          <Link href="/app/report">
            <Button>
              <PlusCircle className="h-4 w-4" /> New Listing
            </Button>
          </Link>
        </div>
      </section>

      {/* Real-time stats grid */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="p-5">
            <div className="flex items-center justify-between">
              <span
                className={`inline-flex h-10 w-10 items-center justify-center rounded-xl ${s.tone}`}
              >
                <s.icon className="h-5 w-5" />
              </span>
            </div>
            <p className="mt-3.5 text-3xl font-extrabold leading-none text-ink">
              {s.value}
            </p>
            <p className="mt-1 text-[13px] font-bold text-ink">{s.label}</p>
            <p className="mt-0.5 text-xs text-muted">{s.sub}</p>
          </Card>
        ))}
      </section>

      {/* Potential Matches highlight banner */}
      {userMatches.length > 0 && (
        <Card className="border-navy-200 bg-gradient-to-r from-navy-50/90 to-blue-50/50 p-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-navy-700 text-white shadow-sm">
                <Sparkles className="h-5 w-5" />
              </span>
              <div>
                <h3 className="font-extrabold text-navy-950 text-base">
                  {userMatches.length} Potential Match{userMatches.length > 1 ? "es" : ""} Detected
                </h3>
                <p className="mt-0.5 text-xs text-navy-800 leading-relaxed max-w-xl">
                  ReFind has found strong matches between your reports and other listings on campus.
                  Review the matches to initiate safe verification.
                </p>
              </div>
            </div>

            <Link href="/app/matches">
              <Button size="sm" className="bg-navy-700 text-white hover:bg-navy-800">
                View Matches ({userMatches.length}) <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </Link>
          </div>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-5">
        {/* Pending requests */}
        <Card className="lg:col-span-3">
          <CardHead
            title="Verification Requests"
            subtitle="People who responded to one of your listings"
            action={
              <Link href="/app/requests">
                <Button variant="ghost" size="sm">
                  View all <ArrowRight className="h-3.5 w-3.5" />
                </Button>
              </Link>
            }
          />
          <div className="p-5">
            {pendingRequests.length === 0 ? (
              <div className="py-10 text-center">
                <Inbox className="mx-auto h-9 w-9 text-navy-200" />
                <p className="mt-3 text-sm font-bold text-ink">
                  No pending requests
                </p>
                <p className="mt-1 text-[13px] text-muted">
                  When someone claims an item you posted, you can verify their description here.
                </p>
              </div>
            ) : (
              <ul className="space-y-3">
                {pendingRequests.map(({ claim, item, claimant }) => (
                  <li key={claim.id}>
                    <Link
                      href="/app/requests"
                      className="flex items-start gap-3 rounded-xl border border-line p-3.5 transition-all hover:border-navy-300 hover:bg-navy-50/50"
                    >
                      <Avatar name={claimant.name} accent={claimant.accent} size={36} />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold text-ink">
                            {claimant.name}
                          </p>
                          <span className="text-[11px] capitalize text-muted">({claimant.role})</span>
                        </div>
                        <p className="line-clamp-1 text-[13px] text-navy-700 font-semibold mt-0.5">
                          on &ldquo;{item.title}&rdquo;
                        </p>
                        <p className="line-clamp-1 text-xs text-muted mt-0.5">
                          &ldquo;{claim.message}&rdquo;
                        </p>
                      </div>
                      <Badge tone="amber">Needs Review</Badge>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </Card>

        {/* Activity / Notifications */}
        <Card className="lg:col-span-2">
          <CardHead
            title="Recent Activity"
            action={
              <Link href="/app/notifications">
                <Button variant="ghost" size="sm">
                  All <ArrowRight className="h-3.5 w-3.5" />
                </Button>
              </Link>
            }
          />
          <div className="p-5">
            {recentNotifs.length === 0 ? (
              <div className="py-10 text-center">
                <Bell className="mx-auto h-9 w-9 text-navy-200" />
                <p className="mt-3 text-sm font-bold text-ink">
                  No recent activity
                </p>
                <p className="mt-1 text-[13px] text-muted">
                  Notifications for matches, claims and messages appear here.
                </p>
              </div>
            ) : (
              <ul className="space-y-3.5">
                {recentNotifs.map((n) => (
                  <li key={n.id} className="flex gap-3">
                    <span
                      className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${
                        n.seen ? "bg-slate-300" : "bg-navy-600 ring-4 ring-navy-100"
                      }`}
                    />
                    <div className="min-w-0">
                      <p className="text-[13px] font-bold text-ink">{n.title}</p>
                      <p className="line-clamp-2 text-xs text-muted mt-0.5">{n.body}</p>
                      <p className="mt-1 text-[11px] text-slate-400">
                        {timeAgo(n.createdAt)}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </Card>
      </div>

      {/* Latest listings on campus */}
      <section className="space-y-4">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-lg font-extrabold tracking-tight text-ink">
              Recent Campus Listings
            </h2>
            <p className="text-[13px] text-muted">
              Latest items reported lost or found across the college community.
            </p>
          </div>
          <Link href="/app/browse">
            <Button variant="outline" size="sm">
              <Compass className="h-4 w-4" /> Browse all listings
            </Button>
          </Link>
        </div>

        {recentFeed.length === 0 ? (
          <Empty
            icon={ClipboardList}
            title="No open listings on campus yet"
            text="Be the first to report a lost or found item."
            action={
              <Link href="/app/report">
                <Button>
                  <PlusCircle className="h-4 w-4" /> Report an Item
                </Button>
              </Link>
            }
          />
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {recentFeed.map(({ item, owner }) => (
              <ItemTile key={item.id} item={item} owner={owner} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
