import { and, eq, ne, or } from "drizzle-orm";
import { db } from "@/db";
import { claims, items, matches, messages, notifications } from "@/db/schema";
import { requireUser } from "@/lib/session";
import { AppShell } from "@/components/app-shell";

export const dynamic = "force-dynamic";

export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await requireUser();

  // Pending requests on my listings
  const pendingRows = await db
    .select({ id: claims.id })
    .from(claims)
    .innerJoin(items, eq(claims.itemId, items.id))
    .where(and(eq(items.ownerId, user.id), eq(claims.status, "pending")));

  // Unread notifications
  const unseenNotifs = await db
    .select({ id: notifications.id })
    .from(notifications)
    .where(and(eq(notifications.userId, user.id), eq(notifications.seen, false)));

  // Matches for my items
  const myItems = await db
    .select({ id: items.id })
    .from(items)
    .where(eq(items.ownerId, user.id));
  const myItemIds = new Set(myItems.map((i) => i.id));

  const allMatches = await db.select().from(matches);
  const myMatches = allMatches.filter(
    (m) => (myItemIds.has(m.lostItemId) || myItemIds.has(m.foundItemId)) && m.status !== "dismissed"
  );

  // Unread messages across my approved threads
  const relevant = await db
    .select({ claim: claims, item: items })
    .from(claims)
    .innerJoin(items, eq(claims.itemId, items.id))
    .where(eq(claims.status, "approved"));

  const myThreadIds = new Set(
    relevant
      .filter((r) => r.item.ownerId === user.id || r.claim.claimantId === user.id)
      .map((r) => r.claim.id)
  );

  const unreadMsgs = myThreadIds.size
    ? (
        await db
          .select({ id: messages.id, claimId: messages.claimId })
          .from(messages)
          .where(and(eq(messages.seen, false), ne(messages.senderId, user.id)))
      ).filter((m) => myThreadIds.has(m.claimId))
    : [];

  return (
    <AppShell
      user={{
        name: user.name ?? "Member",
        email: user.email ?? "",
        role: user.role ?? "student",
        accent: user.accent ?? "#1e3a8a",
      }}
      counts={{
        requests: pendingRows.length,
        messages: unreadMsgs.length,
        notifications: unseenNotifs.length,
        matches: myMatches.length,
      }}
    >
      {children}
    </AppShell>
  );
}
