import Link from "next/link";
import { CalendarDays, MapPin, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui";
import { Avatar } from "@/components/ui";
import { ReportImage } from "@/components/report-image";
import { formatDate } from "@/lib/utils";
import type { Item, User } from "@/db/schema";

export function ItemTile({
  item,
  owner,
  href,
  matchScore,
}: {
  item: Item;
  owner: Pick<User, "name" | "accent" | "role" | "department">;
  href?: string;
  matchScore?: number;
}) {
  const isLost = item.kind === "lost";

  return (
    <Link
      href={href ?? `/app/items/${item.id}`}
      className="group block focus-ring rounded-2xl h-full"
    >
      <article className="card h-full flex flex-col overflow-hidden transition-all duration-200 group-hover:-translate-y-1 group-hover:shadow-lg group-hover:shadow-navy-900/10 group-hover:border-navy-300">
        {/* Media */}
        <div className="relative aspect-[16/10] overflow-hidden bg-navy-50 shrink-0">
          <ReportImage
            src={item.imageUrl}
            alt={item.title}
            className="transition-transform duration-300 group-hover:scale-[1.03]"
          />

          <div className="absolute left-3 top-3 flex flex-wrap gap-1.5">
            <Badge tone={isLost ? "red" : "green"}>
              {isLost ? "Lost" : "Found"}
            </Badge>
            {item.status === "returned" && <Badge tone="green">Returned</Badge>}
            {item.status === "claimed" && <Badge tone="amber">Claimed</Badge>}
            {item.status === "closed" && <Badge tone="slate">Closed</Badge>}
          </div>

          {matchScore !== undefined && matchScore > 0 && (
            <div className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-navy-900/90 backdrop-blur px-2.5 py-1 text-[11px] font-bold text-white shadow">
              <Sparkles className="h-3 w-3 text-amber-300" />
              <span>{matchScore}% match</span>
            </div>
          )}
        </div>

        {/* Body */}
        <div className="p-4 flex flex-col flex-1 justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <p className="text-[11px] font-bold uppercase tracking-wide text-navy-600 truncate">
                {item.category}
              </p>
              {item.color && (
                <span className="text-[11px] font-medium text-muted shrink-0">
                  {item.color}
                </span>
              )}
            </div>

            <h3 className="mt-1 line-clamp-1 font-bold text-ink text-base group-hover:text-navy-700 transition-colors">
              {item.title}
            </h3>

            <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-muted">
              {item.description}
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-line space-y-2.5">
            <div className="flex flex-wrap gap-x-3.5 gap-y-1 text-xs text-muted">
              <span className="inline-flex items-center gap-1 font-medium text-slate-700">
                <MapPin className="h-3.5 w-3.5 text-navy-500" />
                <span className="truncate max-w-[140px]">{item.location}</span>
              </span>
              <span className="inline-flex items-center gap-1 font-medium text-slate-600">
                <CalendarDays className="h-3.5 w-3.5 text-slate-400" />
                <span>{formatDate(item.occurredOn)}</span>
              </span>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <Avatar name={owner.name} accent={owner.accent} size={24} />
              <span className="truncate text-xs font-semibold text-ink">
                {owner.name}
              </span>
              <span className="ml-auto text-[11px] capitalize text-muted">
                {owner.role}
              </span>
            </div>
          </div>
        </div>
      </article>
    </Link>
  );
}
