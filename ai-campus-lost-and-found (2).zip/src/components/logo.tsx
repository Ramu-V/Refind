import { cn } from "@/lib/utils";

/** ReFind mark — a location pin fused with a magnifying lens. */
export function Logo({
  size = 36,
  className,
}: {
  size?: number;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded-xl bg-navy-700 text-white shadow-sm shadow-navy-900/25",
        className
      )}
      style={{ width: size, height: size }}
    >
      <svg
        width={size * 0.6}
        height={size * 0.6}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z" />
        <circle cx="12" cy="9.6" r="2.6" />
      </svg>
    </span>
  );
}

export function Wordmark({
  size = 36,
  className,
  tone = "dark",
}: {
  size?: number;
  className?: string;
  tone?: "dark" | "light";
}) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <Logo size={size} />
      <span
        className={cn(
          "text-[19px] font-extrabold tracking-tight",
          tone === "dark" ? "text-ink" : "text-white"
        )}
      >
        Re<span className="text-navy-500">Find</span>
      </span>
    </span>
  );
}
