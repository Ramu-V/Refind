"use client";

import { useEffect, useOptimistic, useRef, useState, useTransition } from "react";
import { Send } from "lucide-react";
import { toast } from "sonner";
import { sendMessage } from "@/actions/messages";
import { Avatar, Button, Input } from "@/components/ui";
import { cn, timeAgo } from "@/lib/utils";
import type { Message, User } from "@/db/schema";

type Entry = { message: Message; sender: User };

export function Chat({
  claimId,
  initial,
  me,
}: {
  claimId: string;
  initial: Entry[];
  me: { id: string; name: string; accent: string };
}) {
  const [, start] = useTransition();
  const [entries, setEntries] = useState<Entry[]>(initial);
  const [optimistic, addOptimistic] = useOptimistic(
    entries,
    (state: Entry[], body: string) => [
      ...state,
      {
        message: {
          id: `temp-${Date.now()}`,
          claimId,
          senderId: me.id,
          body,
          seen: false,
          createdAt: new Date(),
        } as Message,
        sender: { id: me.id, name: me.name, accent: me.accent } as User,
      },
    ]
  );

  const bottomRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => setEntries(initial), [initial]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [optimistic.length]);

  async function onSubmit(formData: FormData) {
    const body = String(formData.get("body") ?? "").trim();
    if (!body) return;

    formRef.current?.reset();
    start(async () => {
      addOptimistic(body);
      const res = await sendMessage(claimId, formData);
      if (res.error) toast.error(res.error);
    });
  }

  return (
    <>
      <div className="flex-1 space-y-3 overflow-y-auto px-5 py-5">
        {optimistic.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted">
            No messages yet — start the conversation.
          </p>
        ) : (
          optimistic.map(({ message, sender }) => {
            const mine = message.senderId === me.id;
            return (
              <div
                key={message.id}
                className={cn("flex gap-2.5", mine ? "justify-end" : "justify-start")}
              >
                {!mine && (
                  <Avatar name={sender.name} accent={sender.accent} size={30} className="mt-auto" />
                )}
                <div className={cn("max-w-[78%]", mine && "items-end")}>
                  <div
                    className={cn(
                      "px-4 py-2.5 text-sm leading-relaxed",
                      mine
                        ? "rounded-2xl rounded-br-sm bg-navy-700 text-white"
                        : "rounded-2xl rounded-bl-sm border border-line bg-white text-ink"
                    )}
                  >
                    {message.body}
                  </div>
                  <p
                    className={cn(
                      "mt-1 text-[11px] text-slate-400",
                      mine ? "text-right" : "text-left"
                    )}
                  >
                    {timeAgo(message.createdAt)}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      <form
        ref={formRef}
        action={onSubmit}
        className="flex gap-2 border-t border-line bg-white p-4"
      >
        <Input
          name="body"
          placeholder="Write a message…"
          autoComplete="off"
          required
          className="flex-1"
        />
        <Button type="submit" size="icon" aria-label="Send message">
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </>
  );
}
