"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTransition } from "react";
import {
  Bell,
  CheckCheck,
  Handshake,
  Inbox,
  MessageCircle,
  Sparkles,
  XCircle,
} from "lucide-react";
import { markAllNotificationsSeen, markNotificationSeen } from "@/actions/account";
import { Badge, Button, Card } from "@/components/ui";
import { cn, timeAgo } from "@/lib/utils";
import type { Notification } from "@/db/schema";

const ICONS = {
  claim_received: Inbox,
  claim_approved: Handshake,
  claim_declined: XCircle,
  new_message: MessageCircle,
  item_returned: CheckCheck,
  possible_match: Sparkles,
} as const;

const TONES = {
  claim_received: "bg-amber-50 text-amber-600",
  claim_approved: "bg-emerald-50 text-emerald-600",
  claim_declined: "bg-slate-100 text-slate-500",
  new_message: "bg-navy-50 text-navy-600",
  item_returned: "bg-emerald-50 text-emerald-600",
  possible_match: "bg-navy-50 text-navy-600",
} as const;

export function NotificationList({ items }: { items: Notification[] }) {
  const router = useRouter();
  const [pending, start] = useTransition();

  const unseen = items.filter((n) => !n.seen).length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-ink">
            Notifications
          </h1>
          <p className="mt-1 text-sm text-muted">
            {unseen > 0 ? `${unseen} unread` : "You're all caught up"}
          </p>
        </div>

        {unseen > 0 && (
          <Button
            variant="outline"
            size="sm"
            disabled={pending}
            onClick={() =>
              start(async () => {
                await markAllNotificationsSeen();
                router.refresh();
              })
            }
          >
            <CheckCheck className="h-4 w-4" /> Mark all read
          </Button>
        )}
      </div>

      {items.length === 0 ? (
        <Card className="px-6 py-16 text-center">
          <Bell className="mx-auto h-10 w-10 text-navy-200" />
          <p className="mt-4 font-bold text-ink">Nothing here yet</p>
          <p className="mt-1.5 text-sm text-muted">
            Requests, approvals and messages will appear here.
          </p>
        </Card>
      ) : (
        <Card className="divide-y divide-line overflow-hidden p-0">
          {items.map((n) => {
            const Icon = ICONS[n.kind] ?? Bell;
            const tone = TONES[n.kind] ?? "bg-navy-50 text-navy-600";

            const body = (
              <div
                className={cn(
                  "flex items-start gap-4 p-4 transition-colors",
                  !n.seen && "bg-navy-50/40"
                )}
              >
                <span
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                    tone
                  )}
                >
                  <Icon className="h-[18px] w-[18px]" />
                </span>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-ink">{n.title}</p>
                    {!n.seen && <Badge tone="navy">New</Badge>}
                  </div>
                  <p className="mt-0.5 text-[13px] leading-relaxed text-muted">
                    {n.body}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-400">
                    {timeAgo(n.createdAt)}
                  </p>
                </div>

                {!n.seen && (
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      start(async () => {
                        await markNotificationSeen(n.id);
                        router.refresh();
                      });
                    }}
                    className="shrink-0 rounded-lg p-1.5 text-muted hover:bg-white hover:text-navy-700"
                    aria-label="Mark as read"
                  >
                    <CheckCheck className="h-4 w-4" />
                  </button>
                )}
              </div>
            );

            return n.href ? (
              <Link key={n.id} href={n.href} className="block hover:bg-navy-50/60">
                {body}
              </Link>
            ) : (
              <div key={n.id}>{body}</div>
            );
          })}
        </Card>
      )}
    </div>
  );
}
