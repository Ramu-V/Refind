"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Handshake,
  Loader2,
  Lock,
  MessageCircle,
  Pencil,
  RotateCcw,
  Send,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { deleteItem, markReturned, reopenItem, closeItem } from "@/actions/items";
import { submitClaim, decideClaim } from "@/actions/claims";
import { Button, Card, CardHead, Label, Textarea, Avatar, Badge, Input } from "@/components/ui";
import { timeAgo } from "@/lib/utils";
import type { Claim, Item, User } from "@/db/schema";

/* ───────── Owner controls ───────── */

export function OwnerControls({ item }: { item: Item }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [confirming, setConfirming] = useState(false);

  const run = (fn: () => Promise<{ error?: string }>, success: string, to?: string) =>
    start(async () => {
      const res = await fn();
      if (res.error) {
        toast.error(res.error);
        return;
      }
      toast.success(success);
      if (to) router.push(to);
      router.refresh();
    });

  return (
    <Card className="border-line shadow-sm">
      <CardHead title="Manage Your Listing" subtitle="Listing owner controls" />
      <div className="space-y-2.5 p-5">
        <Link href={`/app/items/${item.id}/edit`} className="block">
          <Button variant="outline" className="w-full justify-start font-semibold">
            <Pencil className="h-4 w-4 text-navy-600" /> Edit Listing Details
          </Button>
        </Link>

        {item.status === "returned" ? (
          <Button
            variant="outline"
            className="w-full justify-start font-semibold"
            disabled={pending}
            onClick={() => run(() => reopenItem(item.id), "Listing marked as open again")}
          >
            <RotateCcw className="h-4 w-4 text-navy-600" /> Reopen Listing
          </Button>
        ) : (
          <Button
            variant="outline"
            className="w-full justify-start font-semibold text-emerald-800 border-emerald-200 bg-emerald-50/50 hover:bg-emerald-50"
            disabled={pending}
            onClick={() => run(() => markReturned(item.id), "Marked as Returned! 🎉")}
          >
            <CheckCircle2 className="h-4 w-4 text-emerald-600" /> Mark as Returned / Recovered
          </Button>
        )}

        {item.status === "open" && (
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start text-xs text-slate-500 hover:text-slate-800"
            disabled={pending}
            onClick={() => run(() => closeItem(item.id), "Listing closed")}
          >
            <Lock className="h-3.5 w-3.5 mr-1" /> Close listing temporarily
          </Button>
        )}

        {confirming ? (
          <div className="rounded-xl border border-red-200 bg-red-50 p-4 space-y-2 mt-2">
            <p className="text-xs font-bold text-red-800 flex items-center gap-1.5">
              <ShieldAlert className="h-4 w-4 shrink-0" />
              Permanently delete this report?
            </p>
            <p className="text-[11px] text-red-700">
              This action cannot be undone and will remove all associated matches.
            </p>
            <div className="flex gap-2 pt-1">
              <Button
                variant="danger"
                size="sm"
                disabled={pending}
                onClick={() =>
                  run(() => deleteItem(item.id), "Report deleted", "/app/my-items")
                }
              >
                {pending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                Confirm Delete
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs"
                onClick={() => setConfirming(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start text-xs text-red-600 hover:bg-red-50 hover:text-red-700 mt-1"
            onClick={() => setConfirming(true)}
          >
            <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete report
          </Button>
        )}
      </div>
    </Card>
  );
}

/* ───────── Claim form (non-owner) ───────── */

export function ClaimForm({ item }: { item: Item }) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);

  if (sent) {
    return (
      <Card className="border-emerald-200 bg-emerald-50/60 p-5 text-center space-y-2">
        <ShieldCheck className="mx-auto h-10 w-10 text-emerald-600" />
        <h4 className="font-extrabold text-ink text-base">Verification Request Sent</h4>
        <p className="text-xs text-muted leading-relaxed">
          The listing owner has received your request. Once they review your details and approve, a private conversation will automatically open.
        </p>
      </Card>
    );
  }

  async function onSubmit(formData: FormData) {
    setSaving(true);
    setError("");
    const res = await submitClaim(item.id, formData);
    if (res.error) {
      setError(res.error);
      setSaving(false);
      return;
    }
    setSent(true);
    toast.success("Verification request submitted successfully");
    router.refresh();
  }

  const isFound = item.kind === "found";

  return (
    <Card className="border-line shadow-sm">
      <CardHead
        title={isFound ? "Claim This Found Item" : "I Found This Item"}
        subtitle="Secure verification — your contact info stays private until approved."
      />
      <form action={onSubmit} className="space-y-4 p-5">
        {error && (
          <div className="flex items-start gap-2 rounded-xl bg-red-50 px-3.5 py-2.5 text-[13px] font-medium text-red-700">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <Label htmlFor="message">
            {isFound ? "Describe the item to verify ownership *" : "Message to the owner *"}
          </Label>
          <Textarea
            id="message"
            name="message"
            placeholder={
              isFound
                ? "Describe specific details (marks, scratches, stickers, screen lock, case, contents, etc.)..."
                : "Describe where and when you found it, where it is stored, or how the owner can collect it..."
            }
            required
            disabled={saving}
          />
        </div>

        <div>
          <Label htmlFor="proof">Additional verification info (optional)</Label>
          <Textarea
            id="proof"
            name="proof"
            className="min-h-20"
            placeholder="e.g. Serial number, purchase receipt date, photo of item when you owned it..."
            disabled={saving}
          />
        </div>

        <Button type="submit" className="w-full" disabled={saving}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          {saving ? "Sending request…" : "Send Verification Request"}
        </Button>

        <p className="text-[11px] text-muted text-center flex items-center justify-center gap-1.5 pt-1">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
          <span>Protected by ReFind safe verification protocol</span>
        </p>
      </form>
    </Card>
  );
}

/* ───────── Claim review row (owner) ───────── */

export function ClaimReview({
  claim,
  claimant,
}: {
  claim: Claim;
  claimant: User;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();

  const decide = (approve: boolean) =>
    start(async () => {
      const res = await decideClaim(claim.id, approve);
      if (res.error) {
        toast.error(res.error);
        return;
      }
      toast.success(
        approve
          ? "Request approved! Private chat is now unlocked."
          : "Request has been declined."
      );
      router.refresh();
    });

  return (
    <div className="rounded-2xl border border-line bg-white p-4.5 space-y-3.5 shadow-sm">
      <div className="flex items-start gap-3">
        <Avatar name={claimant.name} accent={claimant.accent} size={40} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center justify-between gap-1">
            <div className="flex items-center gap-2">
              <p className="font-bold text-ink text-sm">{claimant.name}</p>
              <span className="text-xs capitalize text-muted">({claimant.role})</span>
            </div>
            <span className="text-[11px] text-slate-400">{timeAgo(claim.createdAt)}</span>
          </div>

          <div className="mt-2 rounded-xl bg-slate-50 p-3 border border-line text-[13px] leading-relaxed text-ink">
            <p className="text-[11px] font-bold uppercase tracking-wide text-muted mb-1">
              Claimant description
            </p>
            <p>{claim.message}</p>
          </div>

          {claim.proof && (
            <div className="mt-2 rounded-xl bg-navy-50/70 p-3 border border-navy-100 text-[13px]">
              <p className="text-[11px] font-bold uppercase tracking-wide text-navy-700 mb-0.5">
                Extra verification proof
              </p>
              <p className="text-slate-700">{claim.proof}</p>
            </div>
          )}

          <div className="mt-4 flex items-center justify-between gap-3 pt-1">
            {claim.status === "pending" ? (
              <div className="flex items-center gap-2">
                <Button size="sm" disabled={pending} onClick={() => decide(true)}>
                  {pending ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Check className="h-3.5 w-3.5" />
                  )}
                  Approve &amp; Open Chat
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={pending}
                  onClick={() => decide(false)}
                >
                  <X className="h-3.5 w-3.5" /> Decline
                </Button>
              </div>
            ) : claim.status === "approved" ? (
              <div className="flex items-center gap-3">
                <Badge tone="green">
                  <CheckCircle2 className="h-3 w-3" /> Approved
                </Badge>
                <Link href={`/app/messages/${claim.id}`}>
                  <Button size="sm" variant="soft">
                    <MessageCircle className="h-3.5 w-3.5" /> Open Messages
                  </Button>
                </Link>
              </div>
            ) : (
              <Badge tone="slate">Declined</Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
