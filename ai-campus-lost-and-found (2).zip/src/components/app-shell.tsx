"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell,
  Compass,
  Handshake,
  Inbox,
  LayoutGrid,
  LogOut,
  Menu,
  MessageCircle,
  PackageSearch,
  PlusCircle,
  Settings,
  Sparkles,
  Tag,
  User,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, Button } from "@/components/ui";
import { Wordmark } from "@/components/logo";
import { logOut } from "@/actions/auth";

const NAV = [
  { href: "/app", label: "Dashboard", icon: LayoutGrid, exact: true },
  { href: "/app/browse", label: "Browse Items", icon: Compass },
  { href: "/app/report?kind=lost", label: "Report Lost Item", icon: PackageSearch },
  { href: "/app/report?kind=found", label: "Report Found Item", icon: Handshake },
  { href: "/app/my-items", label: "My Reports", icon: Tag },
  { href: "/app/matches", label: "Potential Matches", icon: Sparkles, badge: "matches" },
  { href: "/app/requests", label: "Contact Requests", icon: Inbox, badge: "requests" },
  { href: "/app/messages", label: "Messages", icon: MessageCircle, badge: "messages" },
  { href: "/app/notifications", label: "Notifications", icon: Bell, badge: "notifications" },
  { href: "/app/settings", label: "Settings", icon: Settings },
] as const;

export type ShellCounts = {
  requests: number;
  messages: number;
  notifications: number;
  matches: number;
};

export function AppShell({
  children,
  user,
  counts,
}: {
  children: React.ReactNode;
  user: { name: string; email: string; role: string; accent: string };
  counts: ShellCounts;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const isActive = (href: string, exact?: boolean) => {
    const baseHref = href.split("?")[0];
    if (exact) return pathname === href;
    if (href.includes("?kind=")) {
      // For quick report links, match only if on /app/report
      return pathname === "/app/report";
    }
    return pathname === baseHref || pathname.startsWith(baseHref + "/");
  };

  const nav = (
    <>
      <div className="flex h-16 items-center justify-between px-5 border-b border-line">
        <Link href="/" onClick={() => setOpen(false)}>
          <Wordmark size={32} />
        </Link>
        <button
          onClick={() => setOpen(false)}
          className="rounded-lg p-1.5 text-muted hover:bg-navy-50 lg:hidden"
          aria-label="Close menu"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="px-4 py-3">
        <Link href="/app/report" onClick={() => setOpen(false)}>
          <Button className="w-full shadow-sm">
            <PlusCircle className="h-4 w-4" /> Report an Item
          </Button>
        </Link>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 pb-4">
        {NAV.map((n) => {
          const active = isActive(n.href, "exact" in n ? n.exact : false);
          const badgeKey = "badge" in n ? (n.badge as keyof ShellCounts) : null;
          const badgeValue = badgeKey ? counts[badgeKey] : 0;

          return (
            <Link
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold transition-all",
                active
                  ? "bg-navy-700 text-white shadow-sm shadow-navy-900/20"
                  : "text-slate-600 hover:bg-navy-50 hover:text-navy-700"
              )}
            >
              <n.icon className="h-[18px] w-[18px] shrink-0" />
              <span className="flex-1 truncate">{n.label}</span>
              {badgeValue > 0 && (
                <span
                  className={cn(
                    "flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[11px] font-bold shrink-0",
                    active ? "bg-white/20 text-white" : "bg-navy-700 text-white"
                  )}
                >
                  {badgeValue}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-line p-3 bg-white">
        <Link
          href="/app/settings"
          onClick={() => setOpen(false)}
          className="flex items-center gap-3 rounded-xl p-2 hover:bg-navy-50 transition-colors"
        >
          <Avatar name={user.name} accent={user.accent} size={36} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-ink">{user.name}</p>
            <p className="truncate text-xs capitalize text-muted">{user.role}</p>
          </div>
        </Link>
        <form action={logOut}>
          <button
            type="submit"
            className="mt-1 flex w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-slate-500 transition-colors hover:bg-red-50 hover:text-red-600"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </form>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-canvas">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-line bg-white lg:flex">
        {nav}
      </aside>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-ink/40 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
          <aside className="animate-[rise_0.25s_ease-out] absolute inset-y-0 left-0 flex w-72 flex-col border-r border-line bg-white shadow-2xl">
            {nav}
          </aside>
        </div>
      )}

      {/* Main column */}
      <div className="lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-line bg-white/90 px-4 backdrop-blur-md lg:px-8">
          <button
            onClick={() => setOpen(true)}
            className="rounded-lg p-2 text-muted hover:bg-navy-50 lg:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>

          <Link href="/" className="lg:hidden">
            <Wordmark size={28} />
          </Link>

          <div className="ml-auto flex items-center gap-3">
            <Link
              href="/app/matches"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-line text-xs font-semibold text-slate-700 hover:bg-navy-50 hover:border-navy-200 transition-all"
            >
              <Sparkles className="h-3.5 w-3.5 text-navy-600" />
              <span>Matches</span>
              {counts.matches > 0 && (
                <span className="ml-1 rounded-full bg-navy-100 text-navy-800 px-1.5 py-0.2 text-[10px] font-bold">
                  {counts.matches}
                </span>
              )}
            </Link>

            <Link
              href="/app/notifications"
              className="relative rounded-xl border border-line p-2 text-muted transition-colors hover:bg-navy-50 hover:text-navy-700"
              aria-label="Notifications"
            >
              <Bell className="h-[18px] w-[18px]" />
              {counts.notifications > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-bad px-1 text-[10px] font-bold text-white">
                  {counts.notifications}
                </span>
              )}
            </Link>

            <Link href="/app/settings" className="hidden sm:block">
              <Avatar name={user.name} accent={user.accent} size={34} />
            </Link>
          </div>
        </header>

        <main className="animate-[fade_0.3s_ease-out] mx-auto max-w-6xl px-4 py-7 lg:px-8">
          {children}
        </main>
      </div>
    </div>
  );
}
