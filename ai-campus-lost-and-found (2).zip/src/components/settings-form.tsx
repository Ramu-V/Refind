"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import {
  AlertCircle,
  CheckCircle2,
  KeyRound,
  Loader2,
  Lock,
  Phone,
  Save,
  ShieldCheck,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { updateProfile } from "@/actions/account";
import { changePassword } from "@/actions/auth";
import { PREFERRED_CONTACTS } from "@/lib/constants";
import { Avatar, Button, Card, CardHead, Input, Label, Select, Textarea } from "@/components/ui";
import type { User as UserType } from "@/db/schema";

export function SettingsForm({ user }: { user: UserType }) {
  const router = useRouter();
  const { update } = useSession();

  // Profile Form state
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileError, setProfileError] = useState("");
  const [name, setName] = useState(user.name);

  // Password Form state
  const [pwdPending, startPwd] = useTransition();
  const [pwdError, setPwdError] = useState("");
  const [pwdSuccess, setPwdSuccess] = useState("");

  async function onProfileSubmit(formData: FormData) {
    setSavingProfile(true);
    setProfileError("");
    const res = await updateProfile(formData);
    if (res.error) {
      setProfileError(res.error);
      setSavingProfile(false);
      return;
    }
    await update({ name: String(formData.get("name") ?? user.name) });
    toast.success("Profile updated successfully");
    setSavingProfile(false);
    router.refresh();
  }

  function onPasswordSubmit(formData: FormData) {
    setPwdError("");
    setPwdSuccess("");
    startPwd(async () => {
      const res = await changePassword(formData);
      if (res.error) {
        setPwdError(res.error);
        toast.error(res.error);
        return;
      }
      setPwdSuccess("Password changed successfully!");
      toast.success("Password changed successfully!");
      // Reset form fields
      const form = document.getElementById("password-form") as HTMLFormElement | null;
      form?.reset();
    });
  }

  return (
    <div className="space-y-7 max-w-4xl">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">
          Account Settings
        </h1>
        <p className="mt-1 text-sm text-muted">
          Manage your personal profile, contact preferences, and account security.
        </p>
      </div>

      <div className="grid gap-7 lg:grid-cols-3">
        {/* Profile Card */}
        <div className="lg:col-span-2 space-y-7">
          <Card className="overflow-hidden border-line">
            <div className="flex items-center gap-4 border-b border-line bg-navy-50/50 p-5">
              <Avatar name={name || user.name} accent={user.accent} size={60} />
              <div className="min-w-0">
                <p className="truncate text-lg font-extrabold text-ink">
                  {name || user.name}
                </p>
                <p className="truncate text-xs text-muted">{user.email}</p>
                <span className="mt-1 inline-block capitalize text-[11px] font-bold text-navy-700 bg-navy-100/70 px-2 py-0.5 rounded-md">
                  {user.role} {user.department ? `• ${user.department}` : ""}
                </span>
              </div>
            </div>

            <form action={onProfileSubmit} className="space-y-5 p-5 sm:p-6">
              {profileError && (
                <div className="flex items-start gap-2 rounded-xl bg-red-50 px-3.5 py-2.5 text-[13px] font-medium text-red-700">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{profileError}</span>
                </div>
              )}

              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  name="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  disabled={savingProfile}
                />
              </div>

              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  value={user.email}
                  disabled
                  className="bg-slate-50 text-muted cursor-not-allowed"
                />
                <p className="mt-1.5 text-xs text-muted">
                  Used for login and notifications. Cannot be modified directly.
                </p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="role">Campus Role *</Label>
                  <Select id="role" name="role" defaultValue={user.role} disabled={savingProfile}>
                    <option value="student">Student</option>
                    <option value="teacher">Teacher / Faculty</option>
                    <option value="staff">College Staff</option>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="department">Department / Course</Label>
                  <Input
                    id="department"
                    name="department"
                    defaultValue={user.department ?? ""}
                    placeholder="e.g. Computer Science"
                    disabled={savingProfile}
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="phone">Phone Number (Private)</Label>
                  <Input
                    id="phone"
                    name="phone"
                    defaultValue={user.phone ?? ""}
                    placeholder="e.g. +91 98200 12345"
                    disabled={savingProfile}
                  />
                  <p className="mt-1 text-[11px] text-muted">
                    Only shared when you approve a verification request.
                  </p>
                </div>
                <div>
                  <Label htmlFor="preferredContact">Default Contact Preference</Label>
                  <Select
                    id="preferredContact"
                    name="preferredContact"
                    defaultValue={user.preferredContact ?? "chat"}
                    disabled={savingProfile}
                  >
                    {PREFERRED_CONTACTS.map((pc) => (
                      <option key={pc.value} value={pc.value}>{pc.label}</option>
                    ))}
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="bio">About You / Notes</Label>
                <Textarea
                  id="bio"
                  name="bio"
                  defaultValue={user.bio ?? ""}
                  placeholder="e.g. 2nd year student, usually in Science block between 10am-4pm..."
                  className="min-h-20"
                  disabled={savingProfile}
                />
              </div>

              <div className="border-t border-line pt-4 flex justify-end">
                <Button type="submit" disabled={savingProfile}>
                  {savingProfile ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  {savingProfile ? "Saving Profile…" : "Save Profile Changes"}
                </Button>
              </div>
            </form>
          </Card>

          {/* Password & Security Card */}
          <Card className="border-line">
            <CardHead
              title="Change Password"
              subtitle="Keep your account secure with a strong password"
            />
            <form id="password-form" action={onPasswordSubmit} className="space-y-4 p-5 sm:p-6">
              {pwdError && (
                <div className="flex items-start gap-2 rounded-xl bg-red-50 px-3.5 py-2.5 text-[13px] font-medium text-red-700">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{pwdError}</span>
                </div>
              )}

              {pwdSuccess && (
                <div className="flex items-start gap-2 rounded-xl bg-emerald-50 px-3.5 py-2.5 text-[13px] font-medium text-emerald-700">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{pwdSuccess}</span>
                </div>
              )}

              <div>
                <Label htmlFor="currentPassword">Current Password *</Label>
                <Input
                  id="currentPassword"
                  name="currentPassword"
                  type="password"
                  placeholder="••••••••"
                  required
                  disabled={pwdPending}
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="newPassword">New Password *</Label>
                  <Input
                    id="newPassword"
                    name="newPassword"
                    type="password"
                    placeholder="Min 6 characters"
                    minLength={6}
                    required
                    disabled={pwdPending}
                  />
                </div>
                <div>
                  <Label htmlFor="confirmNewPassword">Confirm New Password *</Label>
                  <Input
                    id="confirmNewPassword"
                    name="confirmNewPassword"
                    type="password"
                    placeholder="Repeat new password"
                    minLength={6}
                    required
                    disabled={pwdPending}
                  />
                </div>
              </div>

              <div className="border-t border-line pt-4 flex justify-end">
                <Button type="submit" variant="outline" disabled={pwdPending}>
                  {pwdPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <KeyRound className="h-4 w-4" />
                  )}
                  {pwdPending ? "Updating Password…" : "Update Password"}
                </Button>
              </div>
            </form>
          </Card>
        </div>

        {/* Right Sidebar Info */}
        <div className="space-y-6">
          <Card className="border-line bg-white">
            <CardHead
              title="ReFind Security Guidelines"
              subtitle="How we keep lost & found safe"
            />
            <ul className="space-y-3 p-5">
              {[
                "Your email and phone number are never exposed publicly on any listing.",
                "Anyone claiming an item must provide a description before contact details are unlocked.",
                "Conversations are private and one-on-one between authorized members.",
                "Always arrange handovers in public, well-lit campus spots such as the Library or Main Canteen.",
                "Mark items as 'Returned' once they are handed back to close the report.",
              ].map((text, i) => (
                <li key={i} className="flex items-start gap-2.5 text-xs text-ink leading-relaxed">
                  <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{text}</span>
                </li>
              ))}
            </ul>
          </Card>

          <Card className="border-line p-5 space-y-2.5 bg-navy-50/50">
            <h4 className="font-extrabold text-navy-950 text-sm">Need help or lost your ID card?</h4>
            <p className="text-xs text-muted leading-relaxed">
              If you lost an official Student ID or critical document, remember to also report it at the Campus Security &amp; Admin Block reception.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
