"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  Handshake,
  ImagePlus,
  Loader2,
  MapPin,
  PackageSearch,
  Sparkles,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { createItem, updateItem } from "@/actions/items";
import { CATEGORIES, CAMPUS_SPOTS, COLORS, PREFERRED_CONTACTS } from "@/lib/constants";
import { Button, Card, Input, Label, Select, Textarea } from "@/components/ui";
import { cn, toDateInput } from "@/lib/utils";
import type { Item } from "@/db/schema";

export function ItemForm({
  mode,
  item,
  defaultKind = "lost",
}: {
  mode: "create" | "edit";
  item?: Item;
  defaultKind?: "lost" | "found";
}) {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [kind, setKind] = useState<"lost" | "found">(item?.kind ?? defaultKind);
  // imageUrl is always a durable server URL (or an existing trusted listing URL).
  // previewUrl may temporarily be a blob URL, but is never submitted or persisted.
  const [imageUrl, setImageUrl] = useState(item?.imageUrl ?? "");
  const [previewUrl, setPreviewUrl] = useState(item?.imageUrl ?? "");
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  function clearImage() {
    if (previewUrl.startsWith("blob:")) URL.revokeObjectURL(previewUrl);
    setImageUrl("");
    setPreviewUrl("");
    setPendingFile(null);
    setUploadError("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  async function handleUpload(file: File) {
    const supportedTypes = new Set([
      "image/jpeg",
      "image/jpg",
      "image/pjpeg",
      "image/png",
      "image/webp",
    ]);
    if (!supportedTypes.has(file.type.toLowerCase())) {
      setUploadError("Choose a JPG, JPEG, PNG, or WebP image.");
      toast.error("Choose a JPG, JPEG, PNG, or WebP image.");
      return;
    }
    if (file.size <= 0) {
      setUploadError("The selected image is empty.");
      toast.error("The selected image is empty.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setUploadError("Image must be 5 MB or smaller.");
      toast.error("Image must be 5 MB or smaller.");
      return;
    }

    if (previewUrl.startsWith("blob:")) URL.revokeObjectURL(previewUrl);
    const localPreview = URL.createObjectURL(file);
    setPreviewUrl(localPreview);
    setPendingFile(file);
    setUploadError("");
    setUploading(true);

    try {
      const fd = new FormData();
      fd.append("file", file, file.name);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error ?? `Image upload failed (${res.status}).`);
      if (typeof data.url !== "string" || !data.url.startsWith("/api/images/")) {
        throw new Error("The server did not return a persistent image URL. Please retry.");
      }

      setImageUrl(data.url);
      setPreviewUrl(data.url);
      setPendingFile(null);
      URL.revokeObjectURL(localPreview);
      toast.success("Photo uploaded and safely stored");
    } catch (e) {
      const message = e instanceof Error ? e.message : "Image upload failed. Please retry.";
      setUploadError(message);
      toast.error(message);
    } finally {
      setUploading(false);
    }
  }

  async function onSubmit(formData: FormData) {
    if (pendingFile && !imageUrl.startsWith("/api/images/")) {
      setError("Your selected photo has not finished uploading. Retry the upload or remove it before publishing.");
      return;
    }

    setSaving(true);
    setError("");
    formData.set("kind", kind);
    // Never send previewUrl/blob URLs to the database.
    formData.set("imageUrl", imageUrl);

    try {
      const result =
        mode === "create"
          ? await createItem(formData)
          : await updateItem(item!.id, formData);

      if (result.error) {
        setError(result.error);
        return;
      }

      toast.success(
        mode === "create"
          ? `${kind === "lost" ? "Lost report" : "Found report"} published!`
          : "Listing updated successfully"
      );
      router.push(`/app/items/${result.id}`);
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save the report. Check your connection and retry.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card className="p-6">
      <form action={onSubmit} className="space-y-6">
        {error && (
          <div className="flex items-start gap-2 rounded-xl bg-red-50 px-3.5 py-2.5 text-[13px] font-medium text-red-700">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Kind selector */}
        <div>
          <Label>Report Type *</Label>
          <div className="grid grid-cols-2 gap-3">
            {([
              {
                v: "lost",
                label: "I lost an item",
                desc: "Looking for something you lost on campus",
                icon: PackageSearch,
              },
              {
                v: "found",
                label: "I found an item",
                desc: "Looking to return an item you found",
                icon: Handshake,
              },
            ] as const).map((o) => (
              <button
                key={o.v}
                type="button"
                onClick={() => setKind(o.v)}
                aria-pressed={kind === o.v}
                className={cn(
                  "flex flex-col items-start p-3.5 rounded-xl border text-left transition-all focus-ring",
                  kind === o.v
                    ? "border-navy-700 bg-navy-700 text-white shadow-sm shadow-navy-900/20"
                    : "border-line bg-white text-muted hover:border-navy-200 hover:bg-navy-50"
                )}
              >
                <div className="flex items-center gap-2 font-bold text-sm">
                  <o.icon className="h-4 w-4" />
                  <span>{o.label}</span>
                </div>
                <span className={cn("mt-1 text-xs", kind === o.v ? "text-navy-100" : "text-muted")}>
                  {o.desc}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <Label htmlFor="title">Item title *</Label>
          <Input
            id="title"
            name="title"
            defaultValue={item?.title}
            placeholder={
              kind === "lost"
                ? "e.g. Black North Face backpack with laptop"
                : "e.g. Student ID card found near Library"
            }
            required
            disabled={saving}
          />
        </div>

        <div>
          <Label htmlFor="description">Detailed description *</Label>
          <Textarea
            id="description"
            name="description"
            defaultValue={item?.description}
            placeholder={
              kind === "lost"
                ? "Describe distinctive marks, stickers, engravings, contents, or condition that identify this item..."
                : "Describe general appearance, color, brand, condition. (Tip: Keep one private detail for verification)..."
            }
            required
            disabled={saving}
          />
          <p className="mt-1.5 text-xs text-muted flex items-center gap-1.5">
            <Sparkles className="h-3.5 w-3.5 text-navy-500" />
            <span>More details help ReFind&apos;s intelligent matcher find accurate matches.</span>
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label htmlFor="category">Category *</Label>
            <Select
              id="category"
              name="category"
              defaultValue={item?.category ?? ""}
              required
              disabled={saving}
            >
              <option value="" disabled>Choose a category</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>
          </div>
          <div>
            <Label htmlFor="location">
              {kind === "lost" ? "Where did you lose it? *" : "Where did you find it? *"}
            </Label>
            <Select
              id="location"
              name="location"
              defaultValue={item?.location ?? ""}
              required
              disabled={saving}
            >
              <option value="" disabled>Choose campus location</option>
              {CAMPUS_SPOTS.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </Select>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <Label htmlFor="campusArea">Specific Spot / Room</Label>
            <Input
              id="campusArea"
              name="campusArea"
              defaultValue={item?.campusArea ?? ""}
              placeholder="e.g. 2nd floor desk 14"
              disabled={saving}
            />
          </div>
          <div>
            <Label htmlFor="color">Primary Colour</Label>
            <Select
              id="color"
              name="color"
              defaultValue={item?.color ?? ""}
              disabled={saving}
            >
              <option value="">Not specified</option>
              {COLORS.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>
          </div>
          <div>
            <Label htmlFor="brand">Brand / Model</Label>
            <Input
              id="brand"
              name="brand"
              defaultValue={item?.brand ?? ""}
              placeholder="e.g. Apple, Milton, Nike"
              disabled={saving}
            />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label htmlFor="occurredOn">
              {kind === "lost" ? "Date lost *" : "Date found *"}
            </Label>
            <Input
              id="occurredOn"
              name="occurredOn"
              type="date"
              max={toDateInput(new Date())}
              defaultValue={toDateInput(item?.occurredOn) || toDateInput(new Date())}
              required
              disabled={saving}
            />
          </div>
          <div>
            <Label htmlFor="preferredContact">Preferred Contact Method</Label>
            <Select
              id="preferredContact"
              name="preferredContact"
              defaultValue={item?.preferredContact ?? "chat"}
              disabled={saving}
            >
              {PREFERRED_CONTACTS.map((pc) => (
                <option key={pc.value} value={pc.value}>{pc.label}</option>
              ))}
            </Select>
          </div>
        </div>

        {/* Photo upload section */}
        <div>
          <Label>Item Photo (optional but recommended)</Label>
          {previewUrl ? (
            <div className="relative overflow-hidden rounded-2xl border border-line bg-navy-50">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={previewUrl}
                alt="Preview of selected item photo"
                className="h-56 w-full object-contain bg-slate-100"
                onError={() => {
                  setUploadError("This image preview could not be loaded. Please choose the image again.");
                }}
              />
              {uploading && (
                <div className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-ink/75 px-4 py-3 text-sm font-semibold text-white">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Saving image to persistent storage…
                </div>
              )}
              {!uploading && imageUrl.startsWith("/api/images/") && !uploadError && (
                <div className="absolute bottom-3 left-3 rounded-lg bg-emerald-700/90 px-2.5 py-1 text-xs font-bold text-white">
                  Photo saved
                </div>
              )}
              <button
                type="button"
                onClick={clearImage}
                disabled={uploading || saving}
                className="absolute right-3 top-3 flex items-center gap-1 rounded-xl bg-ink/80 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur hover:bg-ink disabled:opacity-60"
                aria-label="Remove photo"
              >
                <X className="h-3.5 w-3.5" /> Remove photo
              </button>
            </div>
          ) : (
            <label
              className={cn(
                "flex h-40 cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-line bg-navy-50/40 text-muted transition-colors hover:border-navy-300 hover:bg-navy-50",
                uploading && "pointer-events-none opacity-60"
              )}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const f = e.dataTransfer.files?.[0];
                if (f) void handleUpload(f);
              }}
            >
              {uploading ? (
                <Loader2 className="h-7 w-7 animate-spin text-navy-600" />
              ) : (
                <ImagePlus className="h-7 w-7 text-navy-400" />
              )}
              <span className="text-sm font-bold text-ink">
                {uploading ? "Uploading image…" : "Click or drop a photo here"}
              </span>
              <span className="text-xs text-muted">JPG, JPEG, PNG, or WebP · Max 5 MB</span>
              <input
                ref={fileInputRef}
                type="file"
                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                className="hidden"
                disabled={uploading || saving}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  e.target.value = "";
                  if (f) void handleUpload(f);
                }}
              />
            </label>
          )}

          {uploadError && (
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-red-200 bg-red-50 px-3.5 py-3 text-sm text-red-800" role="alert">
              <span className="flex items-start gap-2">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                {uploadError}
              </span>
              {pendingFile && !uploading && (
                <Button type="button" size="sm" variant="outline" onClick={() => void handleUpload(pendingFile)}>
                  Retry upload
                </Button>
              )}
            </div>
          )}

          {!uploadError && pendingFile && !uploading && (
            <p className="mt-2 text-xs font-medium text-amber-700" role="status">
              Photo preview is shown but the image is not stored yet. Retry the upload before publishing.
            </p>
          )}
        </div>

        <div className="flex items-center gap-3 border-t border-line pt-5">
          <Button type="submit" disabled={saving || uploading || Boolean(pendingFile)}>
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            {saving
              ? "Saving report…"
              : mode === "create"
              ? "Publish Report"
              : "Save Changes"}
          </Button>
          <Button
            type="button"
            variant="ghost"
            disabled={saving}
            onClick={() => router.back()}
          >
            Cancel
          </Button>
        </div>
      </form>
    </Card>
  );
}
