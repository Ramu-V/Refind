import {
  pgTable,
  pgEnum,
  uuid,
  text,
  timestamp,
  boolean,
  integer,
  jsonb,
  index,
  uniqueIndex,
  customType,
} from "drizzle-orm/pg-core";

const bytea = customType<{ data: Buffer; driverData: Buffer }>({
  dataType() {
    return "bytea";
  },
});

/* ─────────────── Enums ─────────────── */

export const roleEnum = pgEnum("role", ["student", "teacher", "staff"]);
export const itemKindEnum = pgEnum("item_kind", ["lost", "found"]);
export const itemStatusEnum = pgEnum("item_status", [
  "open",
  "claimed",
  "returned",
  "closed",
]);
export const claimStatusEnum = pgEnum("claim_status", [
  "pending",
  "approved",
  "declined",
]);
export const matchStatusEnum = pgEnum("match_status", [
  "suggested",
  "reviewed",
  "dismissed",
]);
export const notifKindEnum = pgEnum("notif_kind", [
  "claim_received",
  "claim_approved",
  "claim_declined",
  "new_message",
  "item_returned",
  "possible_match",
]);

/* ─────────────── Users ─────────────── */

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    email: text("email").notNull().unique(),
    password: text("password").notNull(),
    role: roleEnum("role").notNull().default("student"),
    department: text("department"),
    phone: text("phone"),
    bio: text("bio"),
    preferredContact: text("preferred_contact").default("chat"),
    accent: text("accent").notNull().default("#1e3a8a"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at")
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [index("users_email_idx").on(t.email)]
);

/* ─────────────── Items ─────────────── */

export const items = pgTable(
  "items",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    kind: itemKindEnum("kind").notNull(),
    title: text("title").notNull(),
    description: text("description").notNull(),
    category: text("category").notNull(),
    color: text("color"),
    brand: text("brand"),
    location: text("location").notNull(),
    campusArea: text("campus_area"),
    occurredOn: timestamp("occurred_on", { mode: "date" }).notNull(),
    imageUrl: text("image_url"),
    status: itemStatusEnum("status").notNull().default("open"),
    preferredContact: text("preferred_contact"),
    keywords: text("keywords").array().notNull().default([]),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at")
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    index("items_owner_idx").on(t.ownerId),
    index("items_kind_idx").on(t.kind),
    index("items_status_idx").on(t.status),
    index("items_category_idx").on(t.category),
    index("items_location_idx").on(t.location),
  ]
);

/* ─────────────── Persistent report image bytes ─────────────── */

export const storedItemImages = pgTable(
  "stored_item_images",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    itemId: uuid("item_id").references(() => items.id, { onDelete: "cascade" }),
    data: bytea("data").notNull(),
    contentType: text("content_type").notNull(),
    originalName: text("original_name").notNull(),
    size: integer("size").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("stored_item_images_owner_idx").on(t.ownerId),
    uniqueIndex("stored_item_images_item_unique").on(t.itemId),
  ]
);

/* ─────────────── Potential Matches ─────────────── */

export const matches = pgTable(
  "matches",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    lostItemId: uuid("lost_item_id")
      .notNull()
      .references(() => items.id, { onDelete: "cascade" }),
    foundItemId: uuid("found_item_id")
      .notNull()
      .references(() => items.id, { onDelete: "cascade" }),
    score: integer("score").notNull(),
    explanation: text("explanation").notNull(),
    signals: jsonb("signals").notNull().default({}),
    status: matchStatusEnum("status").notNull().default("suggested"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at")
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    index("matches_lost_idx").on(t.lostItemId),
    index("matches_found_idx").on(t.foundItemId),
    index("matches_status_idx").on(t.status),
  ]
);

/* ─────────────── Claims / Contact Requests ─────────────── */

export const claims = pgTable(
  "claims",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    itemId: uuid("item_id")
      .notNull()
      .references(() => items.id, { onDelete: "cascade" }),
    claimantId: uuid("claimant_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    message: text("message").notNull(),
    proof: text("proof"),
    status: claimStatusEnum("status").notNull().default("pending"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at")
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    index("claims_item_idx").on(t.itemId),
    index("claims_claimant_idx").on(t.claimantId),
    index("claims_status_idx").on(t.status),
  ]
);

/* ─────────────── Messages ─────────────── */

export const messages = pgTable(
  "messages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    claimId: uuid("claim_id")
      .notNull()
      .references(() => claims.id, { onDelete: "cascade" }),
    senderId: uuid("sender_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    body: text("body").notNull(),
    seen: boolean("seen").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("messages_claim_idx").on(t.claimId)]
);

/* ─────────────── Notifications ─────────────── */

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    kind: notifKindEnum("kind").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    href: text("href"),
    seen: boolean("seen").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("notifications_user_idx").on(t.userId),
    index("notifications_seen_idx").on(t.seen),
  ]
);

export type User = typeof users.$inferSelect;
export type Item = typeof items.$inferSelect;
export type StoredItemImage = typeof storedItemImages.$inferSelect;
export type Match = typeof matches.$inferSelect;
export type Claim = typeof claims.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
